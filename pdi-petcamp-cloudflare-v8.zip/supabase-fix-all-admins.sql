create or replace function public.current_user_is_admin()
returns boolean
language sql
stable
security definer
set search_path = ''
as $$
  select exists (
    select 1
    from public.profiles
    where lower(email) = lower(coalesce(auth.jwt() ->> 'email', ''))
      and role = 'admin'
      and active = true
  );
$$;

revoke all on function public.current_user_is_admin() from public;
grant execute on function public.current_user_is_admin() to authenticated;

drop policy if exists "Administradores podem atualizar qualquer colaborador"
on public.employees;

create policy "Administradores podem atualizar qualquer colaborador"
on public.employees
for update
to authenticated
using (public.current_user_is_admin())
with check (public.current_user_is_admin());

drop policy if exists "Gestores podem atualizar seus colaboradores"
on public.employees;

create policy "Gestores podem atualizar seus colaboradores"
on public.employees
for update
to authenticated
using (lower(manager_email) = lower(coalesce(auth.jwt() ->> 'email', '')))
with check (lower(manager_email) = lower(coalesce(auth.jwt() ->> 'email', '')));
