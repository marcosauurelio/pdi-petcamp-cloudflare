type JsonValue = Record<string, unknown> | Array<unknown> | string | number | boolean | null;

export type PdiProfile = {
  email: string;
  name: string;
  role: "admin" | "gestor";
  area: string;
  active: boolean;
};

async function config() {
  const { env } = await import("cloudflare:workers");
  const runtime = env as unknown as Record<string, string | undefined>;
  const url = runtime.SUPABASE_URL || process.env.SUPABASE_URL;
  const key = runtime.NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY || process.env.NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY;
  if (!url || !key) throw new Error("A conexão com o Supabase ainda não foi configurada.");
  return { url: url.replace(/\/$/, ""), key };
}

export function cleanText(value: unknown, limit = 500) {
  return String(value ?? "").replace(/[\u0000-\u001f\u007f]/g, " ").replace(/\s+/g, " ").trim().slice(0, limit);
}

export function cleanEmail(value: unknown) {
  const email = cleanText(value, 180).toLowerCase();
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) ? email : "";
}

export function pinPassword(pin: string) {
  return `Pdi#${pin}Petcamp!`;
}

export function readCookie(request: Request, name: string) {
  const cookies = request.headers.get("cookie") || "";
  const item = cookies.split(";").map((part) => part.trim()).find((part) => part.startsWith(`${name}=`));
  return item ? decodeURIComponent(item.slice(name.length + 1)) : "";
}

function authenticatedEmail(request: Request) {
  const token = readCookie(request, "pdi_sb_token");
  const payload = token.split(".")[1];
  if (!payload) return "";
  try {
    const normalized = payload.replace(/-/g, "+").replace(/_/g, "/");
    const padded = normalized.padEnd(Math.ceil(normalized.length / 4) * 4, "=");
    const claims = JSON.parse(atob(padded)) as Record<string, unknown>;
    return cleanEmail(claims.email);
  } catch {
    return "";
  }
}

export function sessionCookie(token: string, maxAge = 3600) {
  return `pdi_sb_token=${encodeURIComponent(token)}; Path=/; HttpOnly; Secure; SameSite=Lax; Max-Age=${maxAge}`;
}

export async function supabaseAuth(path: string, body: JsonValue) {
  const { url, key } = await config();
  return fetch(`${url}/auth/v1/${path}`, {
    method: "POST",
    headers: { apikey: key, "content-type": "application/json" },
    body: JSON.stringify(body),
  });
}

export async function rest<T = unknown>(request: Request, tableAndQuery: string, init: RequestInit = {}) {
  const { url, key } = await config();
  const token = readCookie(request, "pdi_sb_token");
  if (!token) throw new Error("UNAUTHORIZED");
  const headers = new Headers(init.headers);
  headers.set("apikey", key);
  headers.set("authorization", `Bearer ${token}`);
  if (init.body) headers.set("content-type", "application/json");
  const response = await fetch(`${url}/rest/v1/${tableAndQuery}`, { ...init, headers });
  if (response.status === 401) throw new Error("UNAUTHORIZED");
  const text = await response.text();
  const data = text ? JSON.parse(text) : null;
  if (!response.ok) throw new Error(data?.message || data?.details || "Não foi possível acessar o banco Supabase.");
  return data as T;
}

export async function getProfile(request: Request) {
  const email = authenticatedEmail(request);
  if (!email) return null;
  const rows = await rest<Array<PdiProfile>>(request, `profiles?select=email,name,role,area,active&email=eq.${encodeURIComponent(email)}&limit=1`);
  return rows[0] ?? null;
}

export async function audit(request: Request, profile: PdiProfile, action: string, targetType: string, targetName: string, details = "") {
  await rest(request, "audit_logs", {
    method: "POST",
    headers: { Prefer: "return=minimal" },
    body: JSON.stringify({ actor_email: profile.email, actor_name: profile.name, action, target_type: targetType, target_name: targetName, details }),
  });
}
