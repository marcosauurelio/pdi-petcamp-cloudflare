import { QUESTIONS } from "@/lib/pdi-constants";
import { audit, cleanEmail, cleanText, getProfile, rest } from "@/lib/supabase-server";

type Row = Record<string, unknown>;
const bad = (error: string, status = 400) => Response.json({ error }, { status });
const idOf = (value: unknown) => { const id = Number(value); return Number.isInteger(id) && id > 0 ? id : 0; };
const eq = (value: string | number) => encodeURIComponent(String(value));
const duplicateKey = (name: string, manager: string) => `${name.normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase().replace(/\s+/g, " ").trim()}|${manager}`;
const dateOnly = (value: unknown) => {
  const date = cleanText(value, 10);
  return /^\d{4}-\d{2}-\d{2}$/.test(date) && !Number.isNaN(new Date(`${date}T12:00:00`).getTime()) ? date : "";
};

async function employee(request: Request, id: number) {
  const rows = await rest<Row[]>(request, `employees?select=*&id=eq.${id}&limit=1`);
  return rows[0] || null;
}

async function importedJobRole(request: Request, value: string) {
  if (!value) return null;
  const rows = await rest<Row[]>(request, "employees?select=job_role,area&limit=5000");
  const matches = rows.filter((row) => String(row.job_role || "").trim() === value);
  if (!matches.length) return null;
  const areaCounts = new Map<string, number>();
  matches.forEach((row) => {
    const area = cleanText(row.area, 100);
    if (area) areaCounts.set(area, (areaCounts.get(area) || 0) + 1);
  });
  const area = [...areaCounts.entries()].sort((a, b) => b[1] - a[1] || a[0].localeCompare(b[0], "pt-BR"))[0]?.[0] || "";
  return area ? { jobRole: value, area } : null;
}

async function patch(request: Request, path: string, body: Row) {
  return rest(request, path, { method: "PATCH", headers: { Prefer: "return=minimal" }, body: JSON.stringify(body) });
}

async function insert(request: Request, table: string, body: Row | Row[], prefer = "return=minimal") {
  return rest(request, table, { method: "POST", headers: { Prefer: prefer }, body: JSON.stringify(body) });
}

async function remove(request: Request, path: string) {
  return rest(request, path, { method: "DELETE", headers: { Prefer: "return=minimal" } });
}

export async function POST(request: Request) {
  try {
    const profile = await getProfile(request);
    if (!profile || !profile.active) return bad("Sessão encerrada. Entre novamente.", 401);
    const payload = await request.json() as Row;
    const action = cleanText(payload.action, 40);

    if (action === "addManager") {
      if (profile.role !== "admin") return bad("Apenas o administrador pode cadastrar gestores.", 403);
      const name = cleanText(payload.name, 100), email = cleanEmail(payload.email), area = cleanText(payload.area, 100);
      const role = payload.role === "admin" ? "admin" : "gestor";
      if (!name || !email || !area) return bad("Preencha nome, e-mail e área do novo acesso.");
      await insert(request, "profiles?on_conflict=email", { email, name, area, role, active: true }, "resolution=merge-duplicates,return=minimal");
      await audit(request, profile, "Cadastrou acesso", "Gestor", name, `${role} • ${email}`);
      return Response.json({ ok: true, message: "Gestor liberado. Ele deve usar Cadastrar acesso com este e-mail." });
    }

    if (action === "updateManager") {
      if (profile.role !== "admin") return bad("Apenas administradores podem editar acessos.", 403);
      const targetEmail = cleanEmail(payload.targetEmail), name = cleanText(payload.name, 100), area = cleanText(payload.area, 100);
      const role = payload.role === "admin" ? "admin" : "gestor";
      if (!targetEmail || !name || !area) return bad("Preencha nome, área e nível de acesso.");
      if (targetEmail === profile.email && role !== "admin") return bad("Você não pode retirar o próprio acesso de administrador.");
      await patch(request, `profiles?email=eq.${eq(targetEmail)}`, { name, area, role });
      await audit(request, profile, "Editou acesso", "Gestor", name, role);
      return Response.json({ ok: true, message: "Acesso atualizado." });
    }

    if (action === "setManagerActive") {
      if (profile.role !== "admin") return bad("Apenas administradores podem alterar acessos.", 403);
      const targetEmail = cleanEmail(payload.targetEmail), active = payload.active === true;
      if (!targetEmail || (!active && targetEmail === profile.email)) return bad("Você não pode desativar o próprio acesso.");
      if (!active) {
        const assigned = await rest<Row[]>(request, `employees?select=id&manager_email=eq.${eq(targetEmail)}&archived_at=is.null&limit=1`);
        if (assigned.length) return bad("Transfira os colaboradores ativos deste gestor antes de desativá-lo.");
      }
      await patch(request, `profiles?email=eq.${eq(targetEmail)}`, { active });
      await audit(request, profile, active ? "Reativou acesso" : "Desativou acesso", "Gestor", targetEmail);
      return Response.json({ ok: true, message: active ? "Acesso reativado." : "Acesso desativado com segurança." });
    }

    if (action === "addEmployee") {
      const name = cleanText(payload.name, 100), requestedJobRole = cleanText(payload.jobRole, 100);
      const importedRole = await importedJobRole(request, requestedJobRole);
      const jobRole = importedRole?.jobRole || "", area = importedRole?.area || "";
      const birthDate = dateOnly(payload.birthDate), admissionDate = dateOnly(payload.admissionDate);
      const managerEmail = profile.role === "admin" ? cleanEmail(payload.managerEmail) : profile.email;
      if (!name || !requestedJobRole || !area || !birthDate || !admissionDate || !managerEmail) return bad("Preencha todos os dados do colaborador.");
      if (!jobRole) return bad("Selecione um cargo recebido de uma planilha importada.");
      await insert(request, "employees", { name, job_role: jobRole, area, birth_date: birthDate, admission_date: admissionDate, manager_email: managerEmail });
      await audit(request, profile, "Cadastrou colaborador", "Colaborador", name, `${jobRole} • ${area}`);
      return Response.json({ ok: true, message: "Colaborador adicionado à equipe." });
    }

    if (action === "importEmployees") {
      const rows = Array.isArray(payload.rows) ? payload.rows.slice(0, 500) as Row[] : [];
      if (!rows.length) return bad("A planilha não possui colaboradores válidos para importar.");
      const existing = await rest<Row[]>(request, "employees?select=name,manager_email");
      const known = new Set(existing.map((item) => duplicateKey(String(item.name), String(item.manager_email))));
      const inserts: Row[] = []; let skipped = 0;
      for (const row of rows) {
        const name = cleanText(row.name, 100), jobRole = cleanText(row.jobRole, 100), area = cleanText(row.area, 100);
        const birthDate = dateOnly(row.birthDate), admissionDate = dateOnly(row.admissionDate);
        const managerEmail = profile.role === "admin" ? cleanEmail(row.managerEmail) : profile.email;
        const key = duplicateKey(name, managerEmail);
        if (!name || !jobRole || !area || !birthDate || !admissionDate || !managerEmail || known.has(key)) { skipped += 1; continue; }
        known.add(key); inserts.push({ name, job_role: jobRole, area, birth_date: birthDate, admission_date: admissionDate, manager_email: managerEmail });
      }
      for (let i = 0; i < inserts.length; i += 100) await insert(request, "employees", inserts.slice(i, i + 100));
      await audit(request, profile, "Importou colaboradores", "Planilha", `${inserts.length} colaboradores`, `${skipped} ignorados`);
      return Response.json({ ok: true, message: `${inserts.length} colaborador(es) importado(s). ${skipped} linha(s) ignorada(s).` });
    }

    if (action === "updateEmployee") {
      const id = idOf(payload.employeeId), current = id ? await employee(request, id) : null;
      if (!current) return bad("Você não pode editar este colaborador.", 403);
      const name = cleanText(payload.name, 100), requestedJobRole = cleanText(payload.jobRole, 100);
      const importedRole = await importedJobRole(request, requestedJobRole);
      const jobRole = importedRole?.jobRole || "", area = importedRole?.area || "";
      const birthDate = dateOnly(payload.birthDate), admissionDate = dateOnly(payload.admissionDate);
      const managerEmail = profile.role === "admin" ? cleanEmail(payload.managerEmail) : profile.email;
      if (!name || !requestedJobRole || !area || !birthDate || !admissionDate || !managerEmail) return bad("Preencha todos os dados do colaborador.");
      if (!jobRole) return bad("Selecione um cargo recebido de uma planilha importada.");
      await patch(request, `employees?id=eq.${id}`, { name, job_role: jobRole, area, birth_date: birthDate, admission_date: admissionDate, manager_email: managerEmail });
      await audit(request, profile, "Editou colaborador", "Colaborador", name, `${jobRole} • ${area}`);
      return Response.json({ ok: true, message: "Dados do colaborador atualizados." });
    }

    if (action === "setEmployeesArchived") {
      const ids = [...new Set((Array.isArray(payload.employeeIds) ? payload.employeeIds : []).map(idOf).filter(Boolean))].slice(0, 100);
      if (!ids.length) return bad("Selecione pelo menos um colaborador.");
      const archived = payload.archived !== false;
      await patch(request, `employees?id=in.(${ids.join(",")})`, { archived_at: archived ? new Date().toISOString() : null });
      await audit(request, profile, archived ? "Arquivou colaborador" : "Reativou colaborador", "Colaborador", `${ids.length} selecionados`);
      return Response.json({ ok: true, message: `${ids.length} colaborador(es) ${archived ? "arquivado(s)" : "reativado(s)"}.` });
    }

    if (action === "deleteEmployeesPermanently") {
      if (profile.role !== "admin") return bad("Apenas administradores podem excluir colaboradores definitivamente.", 403);
      const ids = [...new Set((Array.isArray(payload.employeeIds) ? payload.employeeIds : []).map(idOf).filter(Boolean))].slice(0, 50);
      if (!ids.length) return bad("Selecione pelo menos um colaborador arquivado.");
      const idList = ids.join(",");
      const archived = await rest<Row[]>(request, `employees?select=id,name&id=in.(${idList})&archived_at=not.is.null`);
      if (archived.length !== ids.length) return bad("Por segurança, somente colaboradores já arquivados podem ser excluídos definitivamente.");
      await remove(request, `checkins?employee_id=in.(${idList})`);
      await remove(request, `pdis?employee_id=in.(${idList})`);
      await remove(request, `evaluations?employee_id=in.(${idList})`);
      await remove(request, `employees?id=in.(${idList})`);
      const names = archived.map((item) => String(item.name)).join(", ");
      await audit(request, profile, "Excluiu colaboradores definitivamente", "Colaborador", names, `${ids.length} cadastro(s) e históricos removidos`);
      return Response.json({ ok: true, message: `${ids.length} colaborador(es) excluído(s) definitivamente.` });
    }

    if (action === "saveEvaluation") {
      const id = idOf(payload.employeeId), current = id ? await employee(request, id) : null;
      if (!current) return bad("Você não pode avaliar este colaborador.", 403);
      const raw = Array.isArray(payload.answers) ? payload.answers : [];
      const answers = raw.map(Number).filter((value) => value >= 1 && value <= 5);
      const status = payload.status === "rascunho" ? "rascunho" : "concluida";
      if (status === "concluida" && answers.length !== QUESTIONS.length) return bad("Responda as 25 perguntas para concluir a avaliação.");
      const cycle = cleanText(payload.cycle, 80) || "Ciclo atual", comments = cleanText(payload.comments, 3000);
      const overall = answers.length ? answers.reduce((sum, value) => sum + value, 0) / answers.length : 0;
      const grouped: Record<string, number[]> = {};
      answers.forEach((answer, index) => { const c = QUESTIONS[index]?.[0]; if (c) (grouped[c] ||= []).push(answer); });
      const averages = Object.fromEntries(Object.entries(grouped).map(([key, values]) => [key, Number((values.reduce((a,b)=>a+b,0)/values.length).toFixed(2))]));
      await insert(request, "evaluations", { employee_id: id, manager_email: profile.email, cycle, answers: raw, overall: Number(overall.toFixed(2)), competency_averages: averages, comments, status });
      if (status === "concluida") await patch(request, `employees?id=eq.${id}`, { score: Number(overall.toFixed(2)), readiness: overall < 2.5 ? "Reversão" : current.readiness });
      await audit(request, profile, status === "rascunho" ? "Salvou avaliação" : "Concluiu avaliação", "Avaliação", String(current.name), cycle);
      return Response.json({ ok: true, message: status === "rascunho" ? "Rascunho salvo." : "Avaliação concluída." });
    }

    if (action === "savePdi" || action === "saveCheckin") {
      const id = idOf(payload.employeeId), current = id ? await employee(request, id) : null;
      if (!current) return bad("Você não pode alterar este colaborador.", 403);
      if (action === "savePdi") {
        const competency = cleanText(payload.competency, 160), action70 = cleanText(payload.action70, 2500);
        const deadline = cleanText(payload.deadline, 20), success = cleanText(payload.successIndicator, 1000);
        if (!competency || !action70 || !deadline || !success) return bad("Preencha a competência, a ação prática, o prazo e o indicador.");
        await insert(request, "pdis", { employee_id: id, manager_email: profile.email, competency, action_70: action70, action_20: cleanText(payload.action20,2500), action_10: cleanText(payload.action10,2500), deadline, success_indicator: success, status: "Ativo" });
        await patch(request, `employees?id=eq.${id}`, { pdi_status: "Ativo" });
        await audit(request, profile, "Criou PDI", "PDI", String(current.name), competency);
        return Response.json({ ok: true, message: "PDI salvo no Supabase." });
      }
      const date = cleanText(payload.date, 20), next = cleanText(payload.nextActions, 2500);
      if (!date || !next) return bad("Informe a data e as próximas ações.");
      await insert(request, "checkins", { employee_id: id, manager_email: profile.email, checkin_date: date, progress: cleanText(payload.progress,2500), risks: cleanText(payload.risks,2500), next_actions: next });
      await audit(request, profile, "Registrou check-in", "Check-in", String(current.name), date);
      return Response.json({ ok: true, message: "Check-in registrado." });
    }
    return bad("Ação não reconhecida.");
  } catch (error) {
    const message = error instanceof Error ? error.message : "Não foi possível salvar.";
    return bad(message === "UNAUTHORIZED" ? "Sessão encerrada. Entre novamente." : message, message === "UNAUTHORIZED" ? 401 : 500);
  }
}
