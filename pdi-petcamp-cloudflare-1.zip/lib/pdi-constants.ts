export const QUESTIONS = [
  ["Resultados e produtividade", "Entrega as atividades dentro dos prazos combinados e mantém um bom ritmo de trabalho."],
  ["Resultados e produtividade", "Executa as tarefas com qualidade, evitando erros e retrabalho."],
  ["Resultados e produtividade", "Define prioridades corretamente diante das demandas do dia a dia."],
  ["Resultados e produtividade", "Demonstra foco para alcançar metas e resultados da área."],
  ["Resultados e produtividade", "Acompanha suas entregas e assume responsabilidade pelos resultados."],
  ["Organização e responsabilidade", "Mantém o ambiente e as atividades de trabalho organizados."],
  ["Organização e responsabilidade", "Cumpre horários, procedimentos e compromissos assumidos."],
  ["Organização e responsabilidade", "Cuida adequadamente dos recursos, materiais e equipamentos da empresa."],
  ["Organização e responsabilidade", "Segue normas e procedimentos de segurança aplicáveis à função."],
  ["Organização e responsabilidade", "Demonstra responsabilidade e confiança na execução das atividades."],
  ["Trabalho em equipe e comunicação", "Colabora com os colegas para alcançar os resultados da equipe."],
  ["Trabalho em equipe e comunicação", "Comunica informações de forma clara, objetiva e respeitosa."],
  ["Trabalho em equipe e comunicação", "Escuta orientações e feedbacks com abertura."],
  ["Trabalho em equipe e comunicação", "Contribui para um ambiente de trabalho respeitoso e colaborativo."],
  ["Trabalho em equipe e comunicação", "Compartilha informações importantes com as pessoas envolvidas."],
  ["Conhecimento e execução da função", "Demonstra conhecimento das atividades e responsabilidades do cargo."],
  ["Conhecimento e execução da função", "Executa os processos conforme os padrões e procedimentos definidos."],
  ["Conhecimento e execução da função", "Resolve situações rotineiras da função com segurança e autonomia."],
  ["Conhecimento e execução da função", "Busca esclarecer dúvidas antes que elas prejudiquem a execução."],
  ["Conhecimento e execução da função", "Aplica corretamente os conhecimentos necessários no dia a dia."],
  ["Iniciativa e desenvolvimento", "Demonstra iniciativa para resolver problemas e apoiar a operação."],
  ["Iniciativa e desenvolvimento", "Busca aprender e melhorar continuamente seu desempenho."],
  ["Iniciativa e desenvolvimento", "Aceita novos desafios e responsabilidades de forma positiva."],
  ["Iniciativa e desenvolvimento", "Propõe melhorias quando identifica oportunidades."],
  ["Iniciativa e desenvolvimento", "Transforma feedbacks recebidos em ações de desenvolvimento."],
] as const;

export const COMPETENCY_NAMES = [...new Set(QUESTIONS.map(([competency]) => competency))];

export type Profile = {
  email: string;
  name: string;
  role: "admin" | "gestor";
  area: string;
  active: number;
};

export type Employee = {
  id: number;
  name: string;
  jobRole: string;
  area: string;
  managerEmail: string;
  managerName: string;
  score: number;
  pdiStatus: string;
  readiness: string;
  archivedAt: string | null;
};

export type AuditLog = {
  id: number;
  actorEmail: string;
  actorName: string;
  action: string;
  targetType: string;
  targetName: string;
  details: string;
  createdAt: string;
};

export type Evaluation = {
  id: number;
  employeeId: number;
  employeeName: string;
  managerEmail: string;
  managerName: string;
  cycle: string;
  overall: number;
  answers: number[];
  competencyAverages: Record<string, number>;
  comments: string;
  status: "rascunho" | "concluida";
  createdAt: string;
};

export type PdiRecord = {
  id: number;
  employeeId: number;
  employeeName: string;
  managerEmail: string;
  competency: string;
  action70: string;
  action20: string;
  action10: string;
  deadline: string;
  successIndicator: string;
  status: string;
  createdAt: string;
};

export type Checkin = {
  id: number;
  employeeId: number;
  employeeName: string;
  managerEmail: string;
  date: string;
  progress: string;
  risks: string;
  nextActions: string;
  createdAt: string;
};

export type BootstrapData = {
  profile: Profile;
  managers: Profile[];
  employees: Employee[];
  evaluations: Evaluation[];
  pdis: PdiRecord[];
  checkins: Checkin[];
  auditLogs: AuditLog[];
};
