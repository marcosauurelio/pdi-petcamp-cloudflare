drop policy if exists "Administradores podem excluir avaliacoes" on public.evaluations;
create policy "Administradores podem excluir avaliacoes"
on public.evaluations for delete to authenticated
using (public.current_user_is_admin());

drop policy if exists "Administradores podem excluir pdis" on public.pdis;
create policy "Administradores podem excluir pdis"
on public.pdis for delete to authenticated
using (public.current_user_is_admin());

drop policy if exists "Administradores podem excluir checkins" on public.checkins;
create policy "Administradores podem excluir checkins"
on public.checkins for delete to authenticated
using (public.current_user_is_admin());

drop policy if exists "Administradores podem excluir colaboradores" on public.employees;
create policy "Administradores podem excluir colaboradores"
on public.employees for delete to authenticated
using (public.current_user_is_admin());
