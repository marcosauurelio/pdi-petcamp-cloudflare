"use client";

import { ChangeEvent, FormEvent, useEffect, useMemo, useState } from "react";
import {
  BootstrapData,
  COMPETENCY_NAMES,
  Employee,
  Evaluation,
  QUESTIONS,
} from "@/lib/pdi-constants";

type PageId = "dashboard" | "gestores" | "colaboradores" | "avaliacao" | "avaliacoes-concluidas" | "pdi" | "checkins" | "relatorios" | "historico";
type ModalId = "gestor" | "editar-gestor" | "colaborador" | "editar-colaborador" | "importar-colaboradores" | null;
type AccessAction = "register" | "login" | "requestReset" | "resetPassword";
type ImportStatus = "valid" | "duplicate" | "error";
type ImportEmployeeRow = {
  rowNumber: number;
  name: string;
  jobRole: string;
  area: string;
  birthDate: string;
  admissionDate: string;
  managerEmail: string;
  managerName: string;
  status: ImportStatus;
  issue: string;
};

const PAGE_TITLES: Record<PageId, string> = {
  dashboard: "Dashboard executivo",
  gestores: "Gestores e acessos",
  colaboradores: "Colaboradores",
  avaliacao: "Avaliação de desempenho",
  "avaliacoes-concluidas": "Avaliações concluídas",
  pdi: "PDI 70-20-10",
  checkins: "Check-ins",
  relatorios: "Relatórios executivos",
  historico: "Histórico de alterações",
};

const NAV_ITEMS: Array<{ id: PageId; label: string; icon: string; adminOnly?: boolean }> = [
  { id: "dashboard", label: "Dashboard", icon: "▦" },
  { id: "gestores", label: "Gestores", icon: "♙", adminOnly: true },
  { id: "colaboradores", label: "Colaboradores", icon: "◎" },
  { id: "avaliacao", label: "Avaliação", icon: "★" },
  { id: "avaliacoes-concluidas", label: "Avaliações concluídas", icon: "✓" },
  { id: "pdi", label: "PDI 70-20-10", icon: "◇" },
  { id: "checkins", label: "Check-ins", icon: "◷" },
  { id: "relatorios", label: "Relatórios", icon: "▤" },
  { id: "historico", label: "Histórico", icon: "◴", adminOnly: true },
];

function initials(name: string) {
  return name
    .split(" ")
    .filter(Boolean)
    .slice(0, 2)
    .map((part) => part[0])
    .join("")
    .toUpperCase();
}

function formatDate(value: string) {
  if (!value) return "Sem data";
  const normalized = /^\d{4}-\d{2}-\d{2}$/.test(value)
    ? `${value}T12:00:00`
    : value.includes(" ")
      ? `${value.replace(" ", "T")}Z`
      : value;
  const date = new Date(normalized);
  return Number.isNaN(date.getTime()) ? value : new Intl.DateTimeFormat("pt-BR").format(date);
}

function yearsSince(value: string) {
  if (!value) return null;
  const start = new Date(`${value}T12:00:00`);
  if (Number.isNaN(start.getTime())) return null;
  const today = new Date();
  let years = today.getFullYear() - start.getFullYear();
  if (today.getMonth() < start.getMonth() || (today.getMonth() === start.getMonth() && today.getDate() < start.getDate())) years -= 1;
  return Math.max(0, years);
}

function companyTime(value: string) {
  if (!value) return "Não informado";
  const start = new Date(`${value}T12:00:00`);
  if (Number.isNaN(start.getTime())) return "Não informado";
  const today = new Date();
  let months = (today.getFullYear() - start.getFullYear()) * 12 + today.getMonth() - start.getMonth();
  if (today.getDate() < start.getDate()) months -= 1;
  months = Math.max(0, months);
  const years = Math.floor(months / 12);
  const remainingMonths = months % 12;
  if (!years) return `${remainingMonths} ${remainingMonths === 1 ? "mês" : "meses"}`;
  if (!remainingMonths) return `${years} ${years === 1 ? "ano" : "anos"}`;
  return `${years} ${years === 1 ? "ano" : "anos"} e ${remainingMonths} ${remainingMonths === 1 ? "mês" : "meses"}`;
}

function formValue(form: FormData, name: string) {
  return String(form.get(name) ?? "");
}

function escapeHtml(value: unknown) {
  return String(value ?? "").replace(/[&<>"']/g, (character) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#039;" })[character] ?? character);
}

function normalizedText(value: unknown) {
  return String(value ?? "")
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .toLowerCase()
    .replace(/[^a-z0-9@.]+/g, " ")
    .replace(/\s+/g, " ")
    .trim();
}

function cellText(value: unknown) {
  if (value instanceof Date) return value.toLocaleDateString("pt-BR");
  return String(value ?? "").trim();
}

function parseDelimitedText(text: string) {
  const firstLine = text.replace(/^\uFEFF/, "").split(/\r?\n/, 1)[0] ?? "";
  const delimiter = (firstLine.match(/;/g)?.length ?? 0) >= (firstLine.match(/,/g)?.length ?? 0) ? ";" : ",";
  const rows: string[][] = [];
  let row: string[] = [];
  let cell = "";
  let quoted = false;
  const source = text.replace(/^\uFEFF/, "");
  for (let index = 0; index < source.length; index += 1) {
    const character = source[index];
    if (character === '"') {
      if (quoted && source[index + 1] === '"') {
        cell += '"';
        index += 1;
      } else {
        quoted = !quoted;
      }
    } else if (character === delimiter && !quoted) {
      row.push(cell);
      cell = "";
    } else if (character === "\n" && !quoted) {
      row.push(cell.replace(/\r$/, ""));
      rows.push(row);
      row = [];
      cell = "";
    } else {
      cell += character;
    }
  }
  if (cell || row.length) {
    row.push(cell.replace(/\r$/, ""));
    rows.push(row);
  }
  return rows;
}

const IMPORT_HEADER_ALIASES = {
  name: ["nome completo", "nome", "colaborador", "funcionario", "funcionário"],
  jobRole: ["cargo", "funcao", "função", "job role"],
  area: ["area", "área", "unidade", "setor"],
  birthDate: ["data de nascimento", "nascimento", "data nascimento"],
  admissionDate: ["data de admissao", "data de admissão", "admissao", "admissão"],
  managerEmail: ["e mail do gestor", "email do gestor", "gestor email", "manager email", "email gestor"],
} as const;

export default function PdiClient() {
  const [data, setData] = useState<BootstrapData | null>(null);
  const [page, setPage] = useState<PageId>("dashboard");
  const [modal, setModal] = useState<ModalId>(null);
  const [menuOpen, setMenuOpen] = useState(false);
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [accessRequired, setAccessRequired] = useState(false);
  const [accessError, setAccessError] = useState("");
  const [toast, setToast] = useState("");
  const [answers, setAnswers] = useState<Record<number, number>>({});
  const [employeeSearch, setEmployeeSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState("");
  const [selectedEmployeeIds, setSelectedEmployeeIds] = useState<number[]>([]);
  const [selectedManagerEmail, setSelectedManagerEmail] = useState("");
  const [importRows, setImportRows] = useState<ImportEmployeeRow[]>([]);
  const [importFileName, setImportFileName] = useState("");
  const [importLoading, setImportLoading] = useState(false);

  async function loadData() {
    setLoading(true);
    try {
      const response = await fetch("/api/bootstrap", { cache: "no-store" });
      const payload = (await response.json()) as BootstrapData & { error?: string };
      if (response.status === 401) {
        setData(null);
        setAccessRequired(true);
        setError("");
        return;
      }
      if (!response.ok) throw new Error(payload.error || "Não foi possível carregar o sistema.");
      setData(payload);
      setAccessRequired(false);
      setError("");
    } catch (loadError) {
      setError(loadError instanceof Error ? loadError.message : "Não foi possível carregar o sistema.");
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    let active = true;
    void fetch("/api/bootstrap", { cache: "no-store" })
      .then(async (response) => {
        const payload = (await response.json()) as BootstrapData & { error?: string };
        if (response.status === 401) return { accessRequired: true as const };
        if (!response.ok) throw new Error(payload.error || "Não foi possível carregar o sistema.");
        return { accessRequired: false as const, payload };
      })
      .then((result) => {
        if (!active) return;
        if (result.accessRequired) {
          setData(null);
          setAccessRequired(true);
          setError("");
          return;
        }
        setData(result.payload);
        setAccessRequired(false);
        setError("");
      })
      .catch((loadError: unknown) => {
        if (!active) return;
        setError(loadError instanceof Error ? loadError.message : "Não foi possível carregar o sistema.");
      })
      .finally(() => {
        if (active) setLoading(false);
      });
    return () => {
      active = false;
    };
  }, []);

  useEffect(() => {
    if (!toast) return;
    const timer = window.setTimeout(() => setToast(""), 2800);
    return () => window.clearTimeout(timer);
  }, [toast]);

  const isAdmin = data?.profile.role === "admin";
  const profiles = data?.managers ?? [];
  const activeProfiles = profiles.filter((manager) => manager.active === 1);
  const administrators = activeProfiles.filter((manager) => manager.role === "admin");
  const managers = activeProfiles.filter((manager) => manager.role === "gestor");
  const inactiveProfiles = profiles.filter((manager) => manager.active !== 1);
  const allEmployees = useMemo(() => data?.employees ?? [], [data?.employees]);
  const employees = useMemo(() => allEmployees.filter((employee) => !employee.archivedAt), [allEmployees]);
  const filteredEmployees = useMemo(() => {
    const term = employeeSearch.trim().toLowerCase();
    const source = statusFilter === "Arquivados" ? allEmployees.filter((employee) => employee.archivedAt) : employees;
    return source.filter((employee) => {
      const matchesText = !term || `${employee.name} ${employee.jobRole} ${employee.area} ${employee.managerName}`.toLowerCase().includes(term);
      const matchesStatus = !statusFilter
        || statusFilter === "Arquivados"
        || (statusFilter === "PDI pendente" ? employee.pdiStatus === "PDI pendente" : employee.readiness === statusFilter);
      return matchesText && matchesStatus;
    });
  }, [allEmployees, employeeSearch, employees, statusFilter]);
  const validImportRows = useMemo(() => importRows.filter((row) => row.status === "valid"), [importRows]);
  const duplicateImportRows = useMemo(() => importRows.filter((row) => row.status === "duplicate"), [importRows]);
  const errorImportRows = useMemo(() => importRows.filter((row) => row.status === "error"), [importRows]);
  const allFilteredEmployeesSelected = filteredEmployees.length > 0 && filteredEmployees.every((employee) => selectedEmployeeIds.includes(employee.id));
  const selectedEmployee = selectedEmployeeIds.length === 1
    ? allEmployees.find((employee) => employee.id === selectedEmployeeIds[0]) ?? null
    : null;
  const selectedManager = profiles.find((manager) => manager.email === selectedManagerEmail) ?? null;

  const metrics = useMemo(() => {
    const completed = (data?.evaluations ?? []).filter((item) => item.status === "concluida");
    const scored = employees.filter((item) => item.score > 0);
    const average = scored.length ? scored.reduce((sum, item) => sum + item.score, 0) / scored.length : 0;
    const ready = employees.length ? Math.round((employees.filter((item) => item.readiness === "Pronto").length / employees.length) * 100) : 0;
    return {
      average,
      activePdis: (data?.pdis ?? []).filter((item) => item.status === "Ativo").length,
      checkins: data?.checkins.length ?? 0,
      completed: completed.length,
      ready,
    };
  }, [data, employees]);

  const managerPerformance = managers.map((manager) => {
    const team = employees.filter((employee) => employee.managerEmail === manager.email);
    const evaluated = team.filter((employee) => employee.score > 0);
    const average = evaluated.length
      ? evaluated.reduce((sum, employee) => sum + employee.score, 0) / evaluated.length
      : 0;
    return {
      email: manager.email,
      name: manager.name,
      area: manager.area,
      teamSize: team.length,
      evaluated: evaluated.length,
      pendingPdis: team.filter((employee) => employee.pdiStatus === "PDI pendente").length,
      average,
    };
  }).sort((first, second) => {
    if (!first.evaluated && second.evaluated) return 1;
    if (first.evaluated && !second.evaluated) return -1;
    return second.average - first.average || first.name.localeCompare(second.name, "pt-BR");
  });

  const competencyAverages = useMemo(() => {
    const completed = (data?.evaluations ?? []).filter((item) => item.status === "concluida");
    return COMPETENCY_NAMES.map((name) => {
      const values = completed.map((item) => item.competencyAverages[name]).filter((value) => Number.isFinite(value));
      const value = values.length ? values.reduce((sum, item) => sum + item, 0) / values.length : 0;
      return { name, value, percent: Math.round((value / 5) * 100) };
    });
  }, [data]);

  function navigate(next: PageId) {
    setPage(next);
    setMenuOpen(false);
    window.scrollTo({ top: 0, behavior: "smooth" });
  }

  async function postAction(body: Record<string, unknown>, successFallback: string) {
    setBusy(true);
    try {
      const response = await fetch("/api/action", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify(body),
      });
      const payload = (await response.json()) as { error?: string; message?: string };
      if (!response.ok) throw new Error(payload.error || "Não foi possível salvar.");
      setToast(payload.message || successFallback);
      await loadData();
      return true;
    } catch (saveError) {
      setToast(saveError instanceof Error ? saveError.message : "Não foi possível salvar.");
      return false;
    } finally {
      setBusy(false);
    }
  }

  async function submitAccess(event: FormEvent<HTMLFormElement>, action: AccessAction) {
    event.preventDefault();
    setBusy(true);
    setAccessError("");
    const form = new FormData(event.currentTarget);
    try {
      const response = await fetch("/api/session", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({
          action,
          name: formValue(form, "name"),
          email: formValue(form, "email"),
          area: formValue(form, "area"),
          pin: formValue(form, "pin"),
          resetCode: formValue(form, "resetCode"),
          newPin: formValue(form, "newPin"),
        }),
      });
      const payload = (await response.json()) as { error?: string; message?: string };
      if (!response.ok) throw new Error(payload.error || "Não foi possível liberar o acesso.");
      setToast(payload.message || "Acesso liberado.");
      if (action === "requestReset" || action === "resetPassword") return true;
      setAccessRequired(false);
      await loadData();
      return true;
    } catch (accessFailure) {
      setAccessError(accessFailure instanceof Error ? accessFailure.message : "Não foi possível liberar o acesso.");
      return false;
    } finally {
      setBusy(false);
    }
  }

  async function signOut() {
    await fetch("/api/session", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ action: "logout" }) });
    setData(null);
    setAccessRequired(true);
    setPage("dashboard");
  }

  async function submitManager(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const formElement = event.currentTarget;
    const form = new FormData(formElement);
    const saved = await postAction(
      {
        action: "addManager",
        name: formValue(form, "name"),
        email: formValue(form, "email"),
        area: formValue(form, "area"),
        birthDate: formValue(form, "birthDate"),
        admissionDate: formValue(form, "admissionDate"),
        role: formValue(form, "role"),
      },
      "Acesso cadastrado.",
    );
    if (saved) {
      formElement.reset();
      setModal(null);
    }
  }

  async function updateManager(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (!selectedManager) return;
    const form = new FormData(event.currentTarget);
    const saved = await postAction({
      action: "updateManager",
      targetEmail: selectedManager.email,
      name: formValue(form, "name"),
      area: formValue(form, "area"),
      role: formValue(form, "role"),
      newPin: formValue(form, "newPin"),
    }, "Acesso atualizado.");
    if (saved) {
      setModal(null);
      setSelectedManagerEmail("");
    }
  }

  async function setManagerActive(email: string, active: boolean) {
    const verb = active ? "reativar" : "desativar";
    if (!window.confirm(`Deseja ${verb} este acesso?`)) return;
    await postAction({ action: "setManagerActive", targetEmail: email, active }, active ? "Acesso reativado." : "Acesso desativado.");
  }

  async function submitEmployee(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const formElement = event.currentTarget;
    const form = new FormData(formElement);
    const saved = await postAction(
      {
        action: "addEmployee",
        name: formValue(form, "name"),
        jobRole: formValue(form, "jobRole"),
        area: formValue(form, "area"),
        managerEmail: isAdmin ? formValue(form, "managerEmail") : data?.profile.email,
      },
      "Colaborador adicionado.",
    );
    if (saved) {
      formElement.reset();
      setModal(null);
    }
  }

  function closeImportModal() {
    setModal(null);
    setImportRows([]);
    setImportFileName("");
  }

  function downloadEmployeeImportTemplate() {
    const exampleManager = isAdmin ? (managers[0]?.email || data?.profile.email || "gestor@empresa.com.br") : (data?.profile.email || "gestor@empresa.com.br");
    const csv = `Nome completo;Cargo;Área;Data de nascimento;Data de admissão;E-mail do gestor\r\nMaria da Silva;Analista de Operações;Operações;15/05/1990;10/01/2020;${exampleManager}\r\n`;
    const blob = new Blob(["\uFEFF", csv], { type: "text/csv;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const anchor = document.createElement("a");
    anchor.href = url;
    anchor.download = "modelo-importacao-colaboradores.csv";
    anchor.click();
    URL.revokeObjectURL(url);
    setToast("Modelo de planilha baixado.");
  }

  async function readEmployeeImportFile(event: ChangeEvent<HTMLInputElement>) {
    const file = event.target.files?.[0];
    event.target.value = "";
    if (!file) return;
    if (file.size > 5 * 1024 * 1024) {
      setToast("A planilha deve ter no máximo 5 MB.");
      return;
    }
    setImportLoading(true);
    setImportRows([]);
    setImportFileName(file.name);
    try {
      let sheetRows: unknown[][];
      if (file.name.toLowerCase().endsWith(".csv")) {
        sheetRows = parseDelimitedText(await file.text());
      } else if (file.name.toLowerCase().endsWith(".xlsx")) {
        const { readSheet } = await import("read-excel-file/browser");
        sheetRows = await readSheet(file) as unknown[][];
      } else {
        throw new Error("Use um arquivo Excel .xlsx ou uma planilha .csv.");
      }

      const headers = (sheetRows[0] ?? []).map(normalizedText);
      const findColumn = (key: keyof typeof IMPORT_HEADER_ALIASES) => headers.findIndex((header) =>
        IMPORT_HEADER_ALIASES[key].some((alias) => normalizedText(alias) === header),
      );
      const columns = {
        name: findColumn("name"),
        jobRole: findColumn("jobRole"),
        area: findColumn("area"),
        birthDate: findColumn("birthDate"),
        admissionDate: findColumn("admissionDate"),
        managerEmail: findColumn("managerEmail"),
      };
      const missing = [
        columns.name < 0 ? "Nome completo" : "",
        columns.jobRole < 0 ? "Cargo" : "",
        columns.area < 0 ? "Área" : "",
        columns.birthDate < 0 ? "Data de nascimento" : "",
        columns.admissionDate < 0 ? "Data de admissão" : "",
        isAdmin && columns.managerEmail < 0 ? "E-mail do gestor" : "",
      ].filter(Boolean);
      if (missing.length) throw new Error(`Colunas não encontradas: ${missing.join(", ")}. Baixe o modelo para conferir os títulos.`);

      const existingKeys = new Set(allEmployees.map((employee) => `${normalizedText(employee.name)}|${employee.managerEmail.toLowerCase()}`));
      const fileKeys = new Set<string>();
      const parsedRows: ImportEmployeeRow[] = [];
      const limitedRows = sheetRows.slice(1, 501);
      limitedRows.forEach((sourceRow, index) => {
        const values = sourceRow.map(cellText);
        if (!values.some(Boolean)) return;
        const name = cellText(sourceRow[columns.name]);
        const jobRole = cellText(sourceRow[columns.jobRole]);
        const area = cellText(sourceRow[columns.area]);
        const toIsoDate = (value: unknown) => {
          if (value instanceof Date) return value.toISOString().slice(0, 10);
          const text = cellText(value);
          const match = text.match(/^(\d{1,2})\/(\d{1,2})\/(\d{4})$/);
          return match ? `${match[3]}-${match[2].padStart(2, "0")}-${match[1].padStart(2, "0")}` : text;
        };
        const birthDate = toIsoDate(sourceRow[columns.birthDate]);
        const admissionDate = toIsoDate(sourceRow[columns.admissionDate]);
        const managerEmail = (isAdmin ? cellText(sourceRow[columns.managerEmail]) : data?.profile.email || "").toLowerCase();
        const manager = activeProfiles.find((item) => item.email.toLowerCase() === managerEmail);
        const key = `${normalizedText(name)}|${managerEmail}`;
        let status: ImportStatus = "valid";
        let issue = "Pronto para importar";
        const missingFields = [!name ? "nome" : "", !jobRole ? "cargo" : "", !area ? "área" : "", !birthDate ? "nascimento" : "", !admissionDate ? "admissão" : "", !managerEmail ? "gestor" : ""].filter(Boolean);
        if (missingFields.length) {
          status = "error";
          issue = `Falta preencher: ${missingFields.join(", ")}`;
        } else if (!manager) {
          status = "error";
          issue = "Gestor não cadastrado ou desativado";
        } else if (existingKeys.has(key)) {
          status = "duplicate";
          issue = "Colaborador já cadastrado";
        } else if (fileKeys.has(key)) {
          status = "duplicate";
          issue = "Duplicado nesta planilha";
        }
        if (status === "valid") fileKeys.add(key);
        parsedRows.push({ rowNumber: index + 2, name, jobRole, area, birthDate, admissionDate, managerEmail, managerName: manager?.name || managerEmail, status, issue });
      });
      if (!parsedRows.length) throw new Error("A planilha não possui linhas preenchidas abaixo do cabeçalho.");
      setImportRows(parsedRows);
      if (sheetRows.length > 501) setToast("Foram analisadas as primeiras 500 linhas da planilha.");
    } catch (readError) {
      setImportFileName("");
      setToast(readError instanceof Error ? readError.message : "Não foi possível ler a planilha.");
    } finally {
      setImportLoading(false);
    }
  }

  async function importEmployees() {
    if (!validImportRows.length) return;
    const saved = await postAction({
      action: "importEmployees",
      rows: validImportRows.map(({ name, jobRole, area, birthDate, admissionDate, managerEmail }) => ({ name, jobRole, area, birthDate, admissionDate, managerEmail })),
    }, "Colaboradores importados.");
    if (saved) closeImportModal();
  }

  async function updateEmployee(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (!selectedEmployee) return;
    const form = new FormData(event.currentTarget);
    const saved = await postAction(
      {
        action: "updateEmployee",
        employeeId: selectedEmployee.id,
        name: formValue(form, "name"),
        jobRole: formValue(form, "jobRole"),
        area: formValue(form, "area"),
        birthDate: formValue(form, "birthDate"),
        admissionDate: formValue(form, "admissionDate"),
        managerEmail: isAdmin ? formValue(form, "managerEmail") : data?.profile.email,
      },
      "Colaborador atualizado.",
    );
    if (saved) {
      setModal(null);
      setSelectedEmployeeIds([]);
    }
  }

  function toggleEmployeeSelection(employeeId: number) {
    setSelectedEmployeeIds((current) => current.includes(employeeId)
      ? current.filter((id) => id !== employeeId)
      : [...current, employeeId]);
  }

  function toggleAllFilteredEmployees() {
    const filteredIds = filteredEmployees.map((employee) => employee.id);
    setSelectedEmployeeIds((current) => allFilteredEmployeesSelected
      ? current.filter((id) => !filteredIds.includes(id))
      : [...new Set([...current, ...filteredIds])]);
  }

  async function setSelectedEmployeesArchived(archived: boolean) {
    if (!selectedEmployeeIds.length) return;
    const count = selectedEmployeeIds.length;
    const confirmed = archived
      ? window.confirm(`Arquivar ${count} colaborador${count === 1 ? "" : "es"}? O histórico de avaliações, PDIs e check-ins será preservado.`)
      : window.confirm(`Reativar ${count} colaborador${count === 1 ? "" : "es"}?`);
    if (!confirmed) return;
    const saved = await postAction(
      { action: "setEmployeesArchived", employeeIds: selectedEmployeeIds, archived },
      archived ? "Colaboradores arquivados." : "Colaboradores reativados.",
    );
    if (saved) setSelectedEmployeeIds([]);
  }

  async function saveEvaluation(formElement: HTMLFormElement, status: "rascunho" | "concluida") {
    const form = new FormData(formElement);
    const orderedAnswers = QUESTIONS.map((_, index) => answers[index] ?? 0);
    const saved = await postAction(
      {
        action: "saveEvaluation",
        employeeId: Number(formValue(form, "employeeId")),
        cycle: formValue(form, "cycle"),
        comments: formValue(form, "comments"),
        answers: orderedAnswers,
        status,
      },
      "Avaliação salva.",
    );
    if (saved && status === "concluida") {
      formElement.reset();
      setAnswers({});
      navigate("avaliacoes-concluidas");
    }
  }

  async function submitEvaluation(event: FormEvent<HTMLFormElement>, status: "rascunho" | "concluida") {
    event.preventDefault();
    await saveEvaluation(event.currentTarget, status);
  }

  async function submitPdi(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const formElement = event.currentTarget;
    const form = new FormData(formElement);
    const saved = await postAction(
      {
        action: "savePdi",
        employeeId: Number(formValue(form, "employeeId")),
        competency: formValue(form, "competency"),
        action70: formValue(form, "action70"),
        action20: formValue(form, "action20"),
        action10: formValue(form, "action10"),
        deadline: formValue(form, "deadline"),
        successIndicator: formValue(form, "successIndicator"),
      },
      "PDI salvo.",
    );
    if (saved) formElement.reset();
  }

  async function submitCheckin(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const formElement = event.currentTarget;
    const form = new FormData(formElement);
    const saved = await postAction(
      {
        action: "saveCheckin",
        employeeId: Number(formValue(form, "employeeId")),
        date: formValue(form, "date"),
        progress: formValue(form, "progress"),
        risks: formValue(form, "risks"),
        nextActions: formValue(form, "nextActions"),
      },
      "Check-in registrado.",
    );
    if (saved) formElement.reset();
  }

  function exportData() {
    if (!data) return;
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const anchor = document.createElement("a");
    anchor.href = url;
    anchor.download = `petcamp-pdi-${new Date().toISOString().slice(0, 10)}.json`;
    anchor.click();
    URL.revokeObjectURL(url);
    setToast("Backup gerado com sucesso.");
  }

  function downloadEvaluationTemplate() {
    const questionRows = QUESTIONS.map(([competency, question], index) => `
      <tr>
        <td class="number">${index + 1}</td>
        <td class="competency">${competency}</td>
        <td>${question}</td>
        <td class="score">☐</td><td class="score">☐</td><td class="score">☐</td><td class="score">☐</td><td class="score">☐</td>
      </tr>`).join("");
    const documentHtml = `<!doctype html><html><head><meta charset="utf-8"><title>Modelo de Avaliação PDI Petcamp</title><style>
      @page{margin:1.4cm}body{font-family:Arial,sans-serif;color:#172033;font-size:10pt;line-height:1.35}h1{color:#123864;font-size:21pt;margin:0 0 4px}h2{color:#123864;font-size:14pt;margin:24px 0 8px}p{margin:4px 0}.brand{border-bottom:4px solid #0874d1;padding-bottom:12px;margin-bottom:18px}.brand b{color:#0874d1}.fields{width:100%;border-collapse:collapse;margin:14px 0}.fields td{padding:8px;border:1px solid #cfd8e3}.label{font-size:8pt;color:#687385;text-transform:uppercase}.scale{padding:10px;background:#eef6ff;border-left:4px solid #0874d1;margin:12px 0}table.questions{width:100%;border-collapse:collapse}.questions th{background:#123864;color:white;font-size:8pt;padding:6px;border:1px solid #d9e0e8}.questions td{padding:6px;border:1px solid #d9e0e8;vertical-align:top}.number,.score{text-align:center;width:24px}.competency{width:105px;font-size:8pt;font-weight:bold;color:#123864}.box{height:80px;border:1px solid #cfd8e3;margin:7px 0 14px}.pdi{width:100%;border-collapse:collapse}.pdi th{background:#eef6ff;color:#123864;padding:7px;border:1px solid #cfd8e3}.pdi td{height:75px;padding:7px;border:1px solid #cfd8e3}.signatures{display:grid;grid-template-columns:1fr 1fr;gap:35px;margin-top:45px}.signature{border-top:1px solid #687385;text-align:center;padding-top:6px}.footer{margin-top:25px;text-align:center;color:#687385;font-size:8pt}</style></head><body>
      <div class="brand"><h1>Petcamp | Avaliação e PDI</h1><p><b>Modelo corporativo de avaliação de desempenho</b> • Ciclo de desenvolvimento</p></div>
      <table class="fields"><tr><td><span class="label">Colaborador</span><br><br></td><td><span class="label">Cargo</span><br><br></td></tr><tr><td><span class="label">Gestor</span><br><br></td><td><span class="label">Ciclo / Data</span><br><br></td></tr></table>
      <div class="scale"><b>Escala:</b> 1 = Precisa desenvolver • 2 = Abaixo do esperado • 3 = Dentro do esperado • 4 = Acima do esperado • 5 = Destaque</div>
      <h2>1. Avaliação de desempenho</h2>
      <table class="questions"><thead><tr><th>Nº</th><th>Competência</th><th>Comportamento avaliado</th><th>1</th><th>2</th><th>3</th><th>4</th><th>5</th></tr></thead><tbody>${questionRows}</tbody></table>
      <h2>2. Comentários e evidências do gestor</h2><div class="box"></div><div class="box"></div>
      <h2>3. Plano de Desenvolvimento Individual — 70-20-10</h2>
      <table class="pdi"><tr><th>70% — Experiência prática</th><th>20% — Aprendizado social</th><th>10% — Aprendizado formal</th></tr><tr><td></td><td></td><td></td></tr></table>
      <table class="fields"><tr><td><span class="label">Competência prioritária</span><br><br></td><td><span class="label">Prazo</span><br><br></td></tr><tr><td colspan="2"><span class="label">Indicador de sucesso</span><br><br></td></tr></table>
      <div class="signatures"><div class="signature">Assinatura do colaborador</div><div class="signature">Assinatura do gestor</div></div>
      <div class="footer">Petcamp • People Development • Modelo gerado pelo sistema PDI</div>
    </body></html>`;
    const blob = new Blob(["\ufeff", documentHtml], { type: "application/msword;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const anchor = document.createElement("a");
    anchor.href = url;
    anchor.download = "modelo-avaliacao-pdi-petcamp.doc";
    anchor.click();
    URL.revokeObjectURL(url);
    setToast("Modelo de avaliação salvo no computador.");
  }

  function downloadCompletedEvaluation(evaluation: Evaluation) {
    const employee = data?.employees.find((item) => item.id === evaluation.employeeId);
    const employeePdis = (data?.pdis ?? []).filter((item) => item.employeeId === evaluation.employeeId);
    const questionRows = QUESTIONS.map(([competency, question], index) => {
      const score = Number(evaluation.answers[index] ?? 0);
      return `<tr><td class="number">${index + 1}</td><td class="competency">${escapeHtml(competency)}</td><td>${escapeHtml(question)}</td><td class="result">${score || "—"}</td></tr>`;
    }).join("");
    const competencyRows = Object.entries(evaluation.competencyAverages).map(([name, value]) => `<tr><td>${escapeHtml(name)}</td><td class="result">${Number(value).toFixed(1).replace(".", ",")}</td></tr>`).join("");
    const pdiSections = employeePdis.length
      ? employeePdis.map((pdi, index) => `
        <div class="pdi-record">
          <h3>Plano ${index + 1} — ${escapeHtml(pdi.competency)}</h3>
          <table class="pdi"><thead><tr><th>70% — Experiência prática</th><th>20% — Aprendizado social</th><th>10% — Aprendizado formal</th></tr></thead><tbody><tr><td class="pdi-action">${escapeHtml(pdi.action70 || "Não informado")}</td><td class="pdi-action">${escapeHtml(pdi.action20 || "Não informado")}</td><td class="pdi-action">${escapeHtml(pdi.action10 || "Não informado")}</td></tr></tbody></table>
          <table class="fields"><tr><td><span class="label">Prazo</span><br><b>${escapeHtml(formatDate(pdi.deadline))}</b></td><td><span class="label">Status</span><br><b>${escapeHtml(pdi.status)}</b></td></tr><tr><td colspan="2"><span class="label">Indicador de sucesso</span><br><b>${escapeHtml(pdi.successIndicator || "Não informado")}</b></td></tr></table>
        </div>`).join("")
      : `<div class="pdi-empty"><b>Nenhum PDI registrado para este colaborador.</b><p>Use este espaço para definir o plano de desenvolvimento.</p><table class="pdi"><thead><tr><th>70% — Experiência prática</th><th>20% — Aprendizado social</th><th>10% — Aprendizado formal</th></tr></thead><tbody><tr><td></td><td></td><td></td></tr></tbody></table><table class="fields"><tr><td><span class="label">Competência prioritária</span><br><br></td><td><span class="label">Prazo</span><br><br></td></tr><tr><td colspan="2"><span class="label">Indicador de sucesso</span><br><br></td></tr></table></div>`;
    const documentHtml = `<!doctype html><html><head><meta charset="utf-8"><title>Avaliação de ${escapeHtml(evaluation.employeeName)}</title><style>
      @page{margin:1.4cm}body{font-family:Arial,sans-serif;color:#172033;font-size:10pt;line-height:1.35}h1{color:#123864;font-size:21pt;margin:0 0 4px}h2{color:#123864;font-size:14pt;margin:24px 0 8px}h3{color:#123864;font-size:11pt;margin:15px 0 7px}.brand{border-bottom:4px solid #0874d1;padding-bottom:12px;margin-bottom:18px}.brand b{color:#0874d1}.fields,.questions,.summary,.pdi{width:100%;border-collapse:collapse;margin:12px 0}.fields td,.questions td,.questions th,.summary td,.summary th,.pdi td,.pdi th{padding:7px;border:1px solid #cfd8e3}.questions th,.summary th{background:#123864;color:white;font-size:8pt}.pdi th{background:#eef6ff;color:#123864;font-size:8pt}.pdi td{height:70px;vertical-align:top}.pdi-action{white-space:pre-wrap}.pdi-record{page-break-inside:avoid;margin-top:12px}.pdi-empty{padding:10px 0}.pdi-empty p{margin:4px 0;color:#687385}.label{font-size:8pt;color:#687385;text-transform:uppercase}.number{width:25px;text-align:center}.competency{width:120px;color:#123864;font-size:8pt;font-weight:bold}.result{width:55px;text-align:center;font-weight:bold}.final{padding:16px;border-radius:8px;background:#eef6ff;border-left:5px solid #0874d1;font-size:13pt}.comments{min-height:90px;padding:12px;border:1px solid #cfd8e3;white-space:pre-wrap}.signatures{display:grid;grid-template-columns:1fr 1fr;gap:35px;margin-top:45px}.signature{border-top:1px solid #687385;text-align:center;padding-top:6px}.footer{margin-top:25px;text-align:center;color:#687385;font-size:8pt}</style></head><body>
      <div class="brand"><h1>Petcamp | Avaliação concluída</h1><p><b>Registro corporativo de desempenho</b> • ${escapeHtml(evaluation.cycle)}</p></div>
      <table class="fields"><tr><td><span class="label">Colaborador</span><br><b>${escapeHtml(evaluation.employeeName)}</b></td><td><span class="label">Cargo</span><br><b>${escapeHtml(employee?.jobRole || "Não informado")}</b></td></tr><tr><td><span class="label">Gestor responsável</span><br><b>${escapeHtml(evaluation.managerName)}</b></td><td><span class="label">Data da avaliação</span><br><b>${escapeHtml(formatDate(evaluation.createdAt))}</b></td></tr><tr><td><span class="label">Área</span><br><b>${escapeHtml(employee?.area || "Não informada")}</b></td><td><span class="label">Ciclo</span><br><b>${escapeHtml(evaluation.cycle)}</b></td></tr></table>
      <div class="final"><b>Resultado final:</b> ${Number(evaluation.overall).toFixed(2).replace(".", ",")} de 5,00</div>
      <h2>Resultados por competência</h2><table class="summary"><thead><tr><th>Competência</th><th>Média</th></tr></thead><tbody>${competencyRows}</tbody></table>
      <h2>Respostas da avaliação</h2><table class="questions"><thead><tr><th>Nº</th><th>Competência</th><th>Comportamento avaliado</th><th>Nota</th></tr></thead><tbody>${questionRows}</tbody></table>
      <h2>Comentários e evidências do gestor</h2><div class="comments">${escapeHtml(evaluation.comments || "Nenhum comentário registrado.")}</div>
      <h2>Plano de Desenvolvimento Individual — 70-20-10</h2>${pdiSections}
      <div class="signatures"><div class="signature">Assinatura do colaborador</div><div class="signature">Assinatura do gestor</div></div>
      <div class="footer">Petcamp • People Development • Avaliação e PDI 70-20-10 registrados no sistema</div>
    </body></html>`;
    const blob = new Blob(["\ufeff", documentHtml], { type: "application/msword;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const anchor = document.createElement("a");
    const safeName = evaluation.employeeName.normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/[^a-z0-9]+/gi, "-").replace(/^-|-$/g, "").toLowerCase();
    anchor.href = url;
    anchor.download = `avaliacao-pdi-${safeName || "colaborador"}-${String(evaluation.createdAt).slice(0, 10)}.doc`;
    anchor.click();
    URL.revokeObjectURL(url);
    setToast("Avaliação e PDI 70-20-10 salvos no computador.");
  }

  async function downloadCompletedEvaluationPdf(evaluation: Evaluation) {
    const { jsPDF } = await import("jspdf");
    const pdf = new jsPDF({ unit: "mm", format: "a4" });
    const employee = data?.employees.find((item) => item.id === evaluation.employeeId);
    const employeePdis = (data?.pdis ?? []).filter((item) => item.employeeId === evaluation.employeeId);
    const pageWidth = 210;
    const margin = 16;
    const contentWidth = pageWidth - margin * 2;
    let y = 18;

    const ensureSpace = (needed: number) => {
      if (y + needed <= 282) return;
      pdf.addPage();
      y = 18;
    };
    const write = (textValue: string, size = 10, options: { bold?: boolean; color?: [number, number, number] } = {}) => {
      pdf.setFont("helvetica", options.bold ? "bold" : "normal");
      pdf.setFontSize(size);
      pdf.setTextColor(...(options.color ?? [30, 40, 55]));
      const lines = pdf.splitTextToSize(textValue || "Não informado", contentWidth) as string[];
      const height = Math.max(5, lines.length * (size * 0.42 + 1));
      ensureSpace(height + 2);
      pdf.text(lines, margin, y);
      y += height;
    };
    const heading = (title: string) => {
      ensureSpace(13);
      y += 4;
      write(title, 13, { bold: true, color: [18, 56, 100] });
      pdf.setDrawColor(8, 116, 209);
      pdf.setLineWidth(0.7);
      pdf.line(margin, y - 3, pageWidth - margin, y - 3);
      y += 2;
    };

    pdf.setFillColor(18, 56, 100);
    pdf.rect(0, 0, pageWidth, 33, "F");
    pdf.setTextColor(255, 255, 255);
    pdf.setFont("helvetica", "bold");
    pdf.setFontSize(20);
    pdf.text("PETCAMP | AVALIAÇÃO E PDI", margin, 16);
    pdf.setFont("helvetica", "normal");
    pdf.setFontSize(9);
    pdf.text("Registro corporativo de desempenho e desenvolvimento", margin, 23);
    y = 42;

    write(`Colaborador: ${evaluation.employeeName}`, 11, { bold: true });
    write(`Cargo: ${employee?.jobRole || "Não informado"}   |   Área: ${employee?.area || "Não informada"}`, 9);
    write(`Gestor: ${evaluation.managerName}   |   Ciclo: ${evaluation.cycle}   |   Data: ${formatDate(evaluation.createdAt)}`, 9);
    y += 2;
    pdf.setFillColor(238, 246, 255);
    pdf.roundedRect(margin, y, contentWidth, 16, 2, 2, "F");
    pdf.setTextColor(8, 80, 145);
    pdf.setFont("helvetica", "bold");
    pdf.setFontSize(14);
    pdf.text(`Nota final: ${Number(evaluation.overall).toFixed(2).replace(".", ",")} de 5,00`, margin + 5, y + 10);
    y += 22;

    heading("Resultados por competência");
    Object.entries(evaluation.competencyAverages).forEach(([name, value]) => {
      write(`${name}: ${Number(value).toFixed(1).replace(".", ",")}`, 9, { bold: true });
    });

    heading("Respostas da avaliação");
    QUESTIONS.forEach(([competency, question], index) => {
      const score = Number(evaluation.answers[index] ?? 0);
      write(`${index + 1}. ${competency} — Nota ${score || "—"}`, 8.5, { bold: true, color: [18, 56, 100] });
      write(question, 8.5);
      y += 1;
    });

    heading("Comentários e evidências do gestor");
    write(evaluation.comments || "Nenhum comentário registrado.", 9);

    heading("Plano de Desenvolvimento Individual — 70-20-10");
    if (!employeePdis.length) {
      write("Nenhum PDI registrado para este colaborador.", 9);
      write("70% — Experiência prática:", 9, { bold: true });
      write("20% — Aprendizado social:", 9, { bold: true });
      write("10% — Aprendizado formal:", 9, { bold: true });
    } else {
      employeePdis.forEach((pdi, index) => {
        ensureSpace(35);
        write(`Plano ${index + 1}: ${pdi.competency}`, 11, { bold: true, color: [18, 56, 100] });
        write(`70% — Experiência prática: ${pdi.action70 || "Não informado"}`, 9);
        write(`20% — Aprendizado social: ${pdi.action20 || "Não informado"}`, 9);
        write(`10% — Aprendizado formal: ${pdi.action10 || "Não informado"}`, 9);
        write(`Prazo: ${formatDate(pdi.deadline)}   |   Indicador de sucesso: ${pdi.successIndicator || "Não informado"}`, 9);
        y += 3;
      });
    }

    ensureSpace(28);
    y += 15;
    pdf.setDrawColor(100, 110, 125);
    pdf.line(margin, y, 92, y);
    pdf.line(118, y, pageWidth - margin, y);
    pdf.setFontSize(8);
    pdf.setTextColor(90, 100, 115);
    pdf.text("Assinatura do colaborador", margin, y + 5);
    pdf.text("Assinatura do gestor", 118, y + 5);

    const safeName = evaluation.employeeName.normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/[^a-z0-9]+/gi, "-").replace(/^-|-$/g, "").toLowerCase();
    pdf.save(`avaliacao-pdi-${safeName || "colaborador"}-${String(evaluation.createdAt).slice(0, 10)}.pdf`);
    setToast("Avaliação em PDF salva no computador.");
  }

  if (loading && !data) {
    return <div className="state-screen"><div className="spinner" /><h1>Preparando seu PDI</h1><p>Carregando equipes e avaliações…</p></div>;
  }

  if (accessRequired && !data) {
    return <ManagerAccess busy={busy} error={accessError} onSubmit={submitAccess} />;
  }

  if (error && !data) {
    return (
      <div className="state-screen error-screen">
        <div className="state-icon">!</div>
        <h1>Acesso ainda não disponível</h1>
        <p>{error}</p>
        <div className="state-actions"><button className="button primary" onClick={() => void loadData()}>Tentar novamente</button></div>
      </div>
    );
  }

  if (!data) return null;

  const emptyTeam = employees.length === 0;
  const topEmployees = employees.slice().sort((a, b) => b.score - a.score).slice(0, 6);

  return (
    <div className="app-shell">
      <aside className={`sidebar ${menuOpen ? "open" : ""}`}>
        <div className="brand-lockup"><div className="brand-mark"><img src="/petcamp-logo.png" alt="Logo Petcamp" /></div><div><strong>Petcamp</strong><span>People Development</span></div></div>
        <nav className="navigation" aria-label="Navegação principal">
          {NAV_ITEMS.filter((item) => !item.adminOnly || isAdmin).map((item) => (
            <button key={item.id} className={page === item.id ? "active" : ""} onClick={() => navigate(item.id)}>
              <span className="nav-icon" aria-hidden="true">{item.icon}</span>{item.label}
            </button>
          ))}
        </nav>
        <div className="sidebar-profile">
          <div className="avatar">{initials(data.profile.name)}</div>
          <div><strong>{data.profile.name}</strong><span>{isAdmin ? "Administrador" : "Gestor"}</span></div>
          <button className="signout" onClick={() => void signOut()} title="Sair" aria-label="Sair">↗</button>
        </div>
      </aside>

      {menuOpen && <button className="menu-overlay" aria-label="Fechar menu" onClick={() => setMenuOpen(false)} />}

      <main className="main-content">
        <header className="topbar">
          <div className="topbar-title"><button className="menu-button" onClick={() => setMenuOpen(true)} aria-label="Abrir menu">☰</button><div><p>Petcamp / Desenvolvimento</p><h1>{PAGE_TITLES[page]}</h1></div></div>
          <div className="topbar-actions"><button className="button secondary desktop-action" onClick={exportData}>Exportar dados</button><button className="button primary" onClick={() => navigate("avaliacao")}>+ Nova avaliação</button></div>
        </header>

        <div className="content-area">
          {page === "dashboard" && (
            <section className="page-section">
              <div className="hero-card">
                <div><span className="eyebrow">GESTÃO DE TALENTOS • MULTIGESTORES</span><h2>Desenvolvimento de pessoas com visão de negócio.</h2><p>{isAdmin ? "Acompanhe todos os gestores, equipes e planos em uma única visão." : "Acompanhe sua equipe, registre conversas e transforme feedbacks em ações."}</p></div>
                <div className="hero-metric"><span>Nota média da equipe</span><strong>{metrics.average ? metrics.average.toFixed(1).replace(".", ",") : "—"}</strong><small>{metrics.completed} avaliações concluídas</small></div>
              </div>

              <div className="kpi-grid">
                <MetricCard label="Colaboradores" value={String(employees.length)} detail={isAdmin ? `${managers.length} gestores ativos` : "Na sua equipe"} />
                <MetricCard label="PDIs ativos" value={String(metrics.activePdis)} detail="Planos em andamento" />
                <MetricCard label="Check-ins" value={String(metrics.checkins)} detail="Registros compartilhados" />
                <MetricCard label="Prontidão" value={`${metrics.ready}%`} detail="Prontos para o próximo nível" />
              </div>

              {emptyTeam ? (
                <EmptyState title="Comece cadastrando sua equipe" text={isAdmin ? "Cadastre os gestores e depois vincule os colaboradores responsáveis por cada equipe." : "Adicione os colaboradores que serão acompanhados por você."} actionLabel={isAdmin ? "Cadastrar gestor" : "Adicionar colaborador"} onAction={() => setModal(isAdmin ? "gestor" : "colaborador")} />
              ) : (
                <div className="dashboard-grid">
                  <article className="card">
                    <div className="card-heading"><div><h3>Competências da equipe</h3><p>Média consolidada das avaliações concluídas</p></div><span className="badge success">Atualizado</span></div>
                    <div className="competency-list">
                      {competencyAverages.map((item) => <div className="competency-row" key={item.name}><div><strong>{item.name}</strong><span>{item.value ? item.value.toFixed(1).replace(".", ",") : "—"}</span></div><div className="progress"><i style={{ width: `${item.percent}%` }} /></div></div>)}
                    </div>
                  </article>
                  <article className="card">
                    <div className="card-heading"><div><h3>Check-ins recentes</h3><p>Acompanhamentos registrados pela equipe</p></div></div>
                    <div className="timeline">
                      {data.checkins.slice(0, 5).map((item) => <div className="timeline-item" key={item.id}><div className="timeline-date">{formatDate(item.date).slice(0, 5)}</div><div><strong>{item.employeeName}</strong><p>{item.nextActions || "Sem próxima ação informada"}</p></div></div>)}
                      {!data.checkins.length && <p className="muted-message">Nenhum check-in registrado ainda.</p>}
                    </div>
                  </article>
                </div>
              )}

              {!emptyTeam && <TeamTable employees={topEmployees} />}
            </section>
          )}

          {page === "gestores" && isAdmin && (
            <section className="page-section">
              <SectionHeader title="Gestores e acessos" text="Cadastre gestores ou outros administradores e acompanhe as equipes." actionLabel="+ Cadastrar acesso" onAction={() => setModal("gestor")} />
              <div className="access-note"><div className="access-icon">✓</div><div><strong>Acesso individual para cada responsável</strong><p>Escolha Gestor ou Administrador. Depois, compartilhe o link para que a pessoa crie seu código numérico usando o e-mail cadastrado.</p></div></div>
              <div className="manager-grid">
                {[...administrators, ...managers, ...inactiveProfiles].map((manager) => {
                  const teamSize = employees.filter((employee) => employee.managerEmail === manager.email).length;
                  return <article className={`manager-card ${manager.role === "admin" ? "admin-card" : ""} ${manager.active ? "" : "manager-inactive"}`} key={manager.email}><div className="avatar large">{initials(manager.name)}</div><div className="manager-card-content"><div className="manager-role-line"><span className={`role-pill ${manager.role === "admin" ? "admin" : ""}`}>{manager.role === "admin" ? "Administrador" : "Gestor"}</span>{!manager.active && <span className="badge muted">Desativado</span>}</div><h3>{manager.name}</h3><p>{manager.email}</p><div className="manager-meta"><span>{manager.area}</span><strong>{teamSize} colaborador{teamSize === 1 ? "" : "es"} ativo{teamSize === 1 ? "" : "s"}</strong></div><div className="manager-actions"><button className="button secondary" onClick={() => { setSelectedManagerEmail(manager.email); setModal("editar-gestor"); }}>✎ Editar</button><button className={`button ${manager.active ? "danger-outline" : "secondary"}`} onClick={() => void setManagerActive(manager.email, !manager.active)}>{manager.active ? "Desativar" : "Reativar"}</button></div></div></article>;
                })}
                {!managers.length && <button className="manager-add-card" onClick={() => setModal("gestor")}><span>＋</span><strong>Adicionar primeiro gestor</strong><small>Libere um novo acesso</small></button>}
              </div>
            </section>
          )}

          {page === "colaboradores" && (
            <section className="page-section">
              <SectionHeader title="Colaboradores" text={isAdmin ? "Consulte todas as equipes e seus responsáveis." : "Cadastre e acompanhe os integrantes da sua equipe."} actionLabel="+ Adicionar colaborador" onAction={() => setModal("colaborador")} />
              <div className="employee-import-card"><div><span className="import-icon">XLSX</span><div><strong>Importar lista de colaboradores</strong><p>Envie uma planilha Excel ou CSV, confira a prévia e importe até 500 pessoas por vez.</p></div></div><div className="employee-import-actions"><span className="pending-pdi-count"><b>{employees.filter((employee) => employee.pdiStatus === "PDI pendente").length}</b> PDI{employees.filter((employee) => employee.pdiStatus === "PDI pendente").length === 1 ? "" : "s"} pendente{employees.filter((employee) => employee.pdiStatus === "PDI pendente").length === 1 ? "" : "s"}</span><button className="button secondary" onClick={downloadEmployeeImportTemplate}>Baixar modelo CSV</button><button className="button primary" onClick={() => setModal("importar-colaboradores")}>Importar Excel</button></div></div>
              <div className="filters card"><input value={employeeSearch} onChange={(event) => setEmployeeSearch(event.target.value)} placeholder="Buscar por nome, cargo, área ou gestor…" aria-label="Buscar colaboradores" /><select value={statusFilter} onChange={(event) => { setStatusFilter(event.target.value); setSelectedEmployeeIds([]); }} aria-label="Filtrar por status"><option value="">Todos os status</option><option>PDI pendente</option><option>Reversão</option><option>Em desenvolvimento</option><option>Pronto</option><option>Arquivados</option></select></div>
              {!!allEmployees.length && <div className="selection-toolbar"><label><input type="checkbox" checked={allFilteredEmployeesSelected} onChange={toggleAllFilteredEmployees} disabled={!filteredEmployees.length || busy} /><span>Selecionar todos os visíveis</span></label><div><strong>{selectedEmployeeIds.length} selecionado{selectedEmployeeIds.length === 1 ? "" : "s"}</strong>{statusFilter === "Arquivados" ? <button className="button primary" disabled={!selectedEmployeeIds.length || busy} onClick={() => void setSelectedEmployeesArchived(false)}>{busy ? "Aguarde…" : "↻ Reativar selecionados"}</button> : <><button className="button secondary" disabled={!selectedEmployee || busy} onClick={() => setModal("editar-colaborador")}>✎ Editar selecionado</button><button className="button warning" disabled={!selectedEmployeeIds.length || busy} onClick={() => void setSelectedEmployeesArchived(true)}>{busy ? "Aguarde…" : "Arquivar selecionados"}</button></>}</div></div>}
              <div className="employee-grid">
                {filteredEmployees.map((employee) => <EmployeeCard employee={employee} key={employee.id} showManager={isAdmin} selected={selectedEmployeeIds.includes(employee.id)} onSelect={toggleEmployeeSelection} />)}
              </div>
              {!filteredEmployees.length && <EmptyState title={statusFilter === "Arquivados" ? "Nenhum colaborador arquivado" : "Nenhum colaborador encontrado"} text={allEmployees.length ? "Altere os filtros para consultar outras pessoas." : "Adicione o primeiro colaborador para começar as avaliações."} actionLabel={allEmployees.length ? undefined : "Adicionar colaborador"} onAction={() => setModal("colaborador")} compact />}
            </section>
          )}

          {page === "avaliacao" && (
            <section className="page-section narrow-section">
              <SectionHeader title="Avaliação de desempenho" text="25 perguntas em 5 competências. Registre evidências e comentários do gestor." />
              <div className="download-model-card"><div><span className="download-icon">⇩</span><div><strong>Modelo de avaliação e PDI</strong><p>Baixe uma cópia editável com as 25 perguntas e o plano 70-20-10.</p></div></div><button className="button secondary" onClick={downloadEvaluationTemplate}>Baixar modelo no PC</button></div>
              {!employees.length ? <EmptyState title="Cadastre um colaborador primeiro" text="A avaliação precisa estar vinculada a uma pessoa da sua equipe." actionLabel="Adicionar colaborador" onAction={() => setModal("colaborador")} /> : (
                <form className="card form-card" onSubmit={(event) => void submitEvaluation(event, "concluida")}>
                  <div className="form-grid two"><label>Colaborador<select name="employeeId" required>{employees.map((employee) => <option value={employee.id} key={employee.id}>{employee.name} — {employee.jobRole}</option>)}</select></label><label>Ciclo<select name="cycle"><option>2º Semestre 2026</option><option>1º Semestre 2027</option><option>Ciclo anual 2026</option></select></label></div>
                  <div className="scale-note"><strong>Escala de avaliação</strong><p><b>1</b> Precisa desenvolver <span>•</span> <b>3</b> Dentro do esperado <span>•</span> <b>5</b> Destaque</p></div>
                  <div className="questions-list">
                    {QUESTIONS.map(([competency, question], index) => {
                      const isFirst = index === 0 || QUESTIONS[index - 1][0] !== competency;
                      return <div key={question}>{isFirst && <div className="question-group"><span>{competency}</span><small>5 perguntas</small></div>}<div className="question"><p><span>{index + 1}</span>{question}</p><div className="rating" role="radiogroup" aria-label={`Nota da pergunta ${index + 1}`}>{[1, 2, 3, 4, 5].map((score) => <label key={score}><input type="radio" name={`q${index}`} value={score} checked={answers[index] === score} onChange={() => setAnswers((current) => ({ ...current, [index]: score }))} required /><span>{score}</span></label>)}</div></div></div>;
                    })}
                  </div>
                  <label>Comentários gerais<textarea name="comments" rows={5} placeholder="Registre evidências, exemplos e orientações para o desenvolvimento…" /></label>
                  <div className="form-actions"><button type="button" className="button secondary" disabled={busy} onClick={(event) => event.currentTarget.form && void saveEvaluation(event.currentTarget.form, "rascunho")}>Salvar rascunho</button><button className="button primary" disabled={busy}>{busy ? "Salvando…" : "Concluir avaliação"}</button></div>
                </form>
              )}
            </section>
          )}

          {page === "avaliacoes-concluidas" && (
            <section className="page-section narrow-section">
              <SectionHeader title="Avaliações concluídas" text="Consulte e baixe as avaliações já realizadas, junto com o PDI 70-20-10." />
              <article className="card completed-evaluations-card">
                <div className="card-heading"><div><h3>Histórico de avaliações</h3><p>Use o botão ao lado de cada colaborador para baixar o relatório completo.</p></div><span className="badge blue">{data.evaluations.filter((item) => item.status === "concluida").length} registros</span></div>
                <div className="evaluation-list">
                  {data.evaluations.filter((item) => item.status === "concluida").map((evaluation) => <div className="evaluation-row" key={evaluation.id}><div className="evaluation-person"><div className="avatar">{initials(evaluation.employeeName)}</div><div><strong>{evaluation.employeeName}</strong><span>{evaluation.cycle} • {formatDate(evaluation.createdAt)}</span></div></div><div className="evaluation-score"><span>Nota final</span><strong>{Number(evaluation.overall).toFixed(2).replace(".", ",")}</strong></div><div className="evaluation-actions"><button className="button secondary" onClick={() => downloadCompletedEvaluation(evaluation)}>⇩ Word + PDI</button><button className="button primary" onClick={() => void downloadCompletedEvaluationPdf(evaluation)}>⇩ Baixar PDF</button></div></div>)}
                  {!data.evaluations.some((item) => item.status === "concluida") && <div className="empty-evaluations"><strong>Nenhuma avaliação concluída</strong><span>Depois de concluir uma avaliação, ela aparecerá nesta aba para download.</span></div>}
                </div>
              </article>
            </section>
          )}

          {page === "pdi" && (
            <section className="page-section narrow-section">
              <SectionHeader title="PDI 70-20-10" text="Transforme oportunidades de desenvolvimento em ações objetivas e acompanháveis." />
              {!employees.length ? <EmptyState title="Cadastre um colaborador primeiro" text="O plano precisa estar vinculado a uma pessoa da sua equipe." actionLabel="Adicionar colaborador" onAction={() => setModal("colaborador")} /> : (
                <form className="card form-card" onSubmit={(event) => void submitPdi(event)}>
                  <div className="form-grid two"><label>Colaborador<select name="employeeId" required>{employees.map((employee) => <option value={employee.id} key={employee.id}>{employee.name} — {employee.jobRole}</option>)}</select></label><label>Competência prioritária<input name="competency" placeholder="Ex.: Liderança e comunicação" required /></label></div>
                  <div className="pdi-grid"><ActionBox weight="70%" title="Experiência prática" description="Projetos, desafios e novas responsabilidades" name="action70" required /><ActionBox weight="20%" title="Aprendizado social" description="Mentoria, feedback, shadowing e pares" name="action20" /><ActionBox weight="10%" title="Aprendizado formal" description="Cursos, leituras, trilhas e workshops" name="action10" /></div>
                  <div className="form-grid two"><label>Prazo<input type="date" name="deadline" required /></label><label>Indicador de sucesso<input name="successIndicator" placeholder="Como saberemos que houve evolução?" required /></label></div>
                  <div className="form-actions"><button className="button primary" disabled={busy}>{busy ? "Salvando…" : "Salvar PDI"}</button></div>
                </form>
              )}
              {!!data.pdis.length && <article className="card records-card"><div className="card-heading"><div><h3>Planos recentes</h3><p>Últimos PDIs registrados</p></div></div><div className="record-list">{data.pdis.slice(0, 8).map((item) => <div className="record-row" key={item.id}><div><strong>{item.employeeName}</strong><span>{item.competency}</span></div><div><span>Prazo</span><strong>{formatDate(item.deadline)}</strong></div><span className="badge blue">{item.status}</span></div>)}</div></article>}
            </section>
          )}

          {page === "checkins" && (
            <section className="page-section narrow-section">
              <SectionHeader title="Check-ins" text="Registre conversas frequentes e mantenha o acompanhamento visível." />
              {!employees.length ? <EmptyState title="Cadastre um colaborador primeiro" text="O check-in precisa estar vinculado a uma pessoa da sua equipe." actionLabel="Adicionar colaborador" onAction={() => setModal("colaborador")} /> : (
                <form className="card form-card" onSubmit={(event) => void submitCheckin(event)}>
                  <div className="form-grid two"><label>Colaborador<select name="employeeId" required>{employees.map((employee) => <option value={employee.id} key={employee.id}>{employee.name} — {employee.jobRole}</option>)}</select></label><label>Data<input name="date" type="date" required /></label></div>
                  <label>Avanços desde o último encontro<textarea name="progress" rows={3} placeholder="O que evoluiu desde a última conversa?" /></label><label>Barreiras ou riscos<textarea name="risks" rows={3} placeholder="O que pode impedir o avanço?" /></label><label>Próximas ações<textarea name="nextActions" rows={3} placeholder="Defina responsáveis e próximos passos…" required /></label>
                  <div className="form-actions"><button className="button primary" disabled={busy}>{busy ? "Salvando…" : "Registrar check-in"}</button></div>
                </form>
              )}
              <article className="card records-card"><div className="card-heading"><div><h3>Histórico compartilhado</h3><p>Registros visíveis para os responsáveis autorizados</p></div></div><div className="timeline detailed">{data.checkins.map((item) => <div className="timeline-item" key={item.id}><div className="timeline-date">{formatDate(item.date).slice(0, 5)}</div><div><strong>{item.employeeName}</strong><p>{item.nextActions}</p><small>{item.progress || "Sem avanço descrito"}</small></div></div>)}{!data.checkins.length && <p className="muted-message">Nenhum check-in registrado ainda.</p>}</div></article>
            </section>
          )}

          {page === "relatorios" && (
            <section className="page-section report-page">
              <SectionHeader title="Relatórios executivos" text={isAdmin ? "Compare o resultado de cada gestor e identifique onde apoiar as equipes." : "Consolidação da sua equipe para acompanhamento mensal."} actionLabel="Imprimir / Salvar PDF" onAction={() => window.print()} />
              <div className="kpi-grid"><MetricCard label={isAdmin ? "Gestores" : "Nota média"} value={isAdmin ? String(managers.length) : metrics.average ? metrics.average.toFixed(1).replace(".", ",") : "—"} detail={isAdmin ? "Ativos no relatório" : "Escala de 1 a 5"} /><MetricCard label="Avaliações" value={String(metrics.completed)} detail="Concluídas" /><MetricCard label="PDIs ativos" value={String(metrics.activePdis)} detail="Em acompanhamento" /><MetricCard label="Prontidão" value={`${metrics.ready}%`} detail="Próximo nível" /></div>
              {isAdmin && <article className="card manager-average-card"><div className="card-heading"><div><h3>Média de desempenho por gestor</h3><p>A média considera a nota atual dos colaboradores avaliados de cada equipe.</p></div><span className="badge blue">Escala de 1 a 5</span></div>{managerPerformance.length ? <div className="table-wrap"><table className="manager-average-table"><thead><tr><th>Gestor</th><th>Equipe</th><th>Avaliados</th><th>Média da equipe</th><th>PDIs pendentes</th></tr></thead><tbody>{managerPerformance.map((manager) => <tr key={manager.email}><td><div className="manager-report-person"><div className="avatar">{initials(manager.name)}</div><div><strong>{manager.name}</strong><span>{manager.area}</span></div></div></td><td><strong>{manager.teamSize}</strong> colaborador{manager.teamSize === 1 ? "" : "es"}</td><td>{manager.evaluated} de {manager.teamSize}</td><td><div className="manager-score"><strong>{manager.evaluated ? manager.average.toFixed(2).replace(".", ",") : "—"}</strong><div className="progress"><i style={{ width: `${manager.evaluated ? Math.round((manager.average / 5) * 100) : 0}%` }} /></div></div></td><td><span className={`badge ${manager.pendingPdis ? "warning" : "success"}`}>{manager.pendingPdis}</span></td></tr>)}</tbody></table></div> : <p className="muted-message">Cadastre os gestores para visualizar a comparação das equipes.</p>}</article>}
              <div className="report-grid"><article className="card"><div className="card-heading"><div><h3>Desempenho por competência</h3><p>Média das avaliações concluídas</p></div></div><div className="competency-list">{competencyAverages.map((item) => <div className="competency-row" key={item.name}><div><strong>{item.name}</strong><span>{item.value ? item.value.toFixed(1).replace(".", ",") : "—"}</span></div><div className="progress"><i style={{ width: `${item.percent}%` }} /></div></div>)}</div></article><article className="card"><h3>Leitura do ciclo</h3><p className="report-copy">{metrics.completed ? "Os dados refletem as avaliações concluídas e os registros de acompanhamento feitos pelos gestores. Use os menores resultados por competência para priorizar os próximos PDIs." : "Conclua as primeiras avaliações para gerar uma leitura consolidada do ciclo."}</p><div className="callout"><strong>Próxima ação recomendada</strong><span>{metrics.activePdis ? "Revisar os prazos dos PDIs ativos nos próximos check-ins." : "Criar um PDI para as competências que precisam de desenvolvimento."}</span></div></article></div>
              <TeamTable employees={topEmployees} />
            </section>
          )}

          {page === "historico" && isAdmin && (
            <section className="page-section narrow-section">
              <SectionHeader title="Histórico de alterações" text="Veja quem cadastrou, editou, arquivou ou alterou informações no sistema." />
              <article className="card audit-card"><div className="card-heading"><div><h3>Atividades registradas</h3><p>Os registros mais recentes aparecem primeiro</p></div><span className="badge blue">{data.auditLogs.length} registros</span></div><div className="audit-list">{data.auditLogs.map((item) => <div className="audit-row" key={item.id}><div className="audit-icon">✓</div><div><strong>{item.action}</strong><p>{item.targetType}: {item.targetName}</p><span>Por {item.actorName} • {formatDate(item.createdAt)}{item.details ? ` • ${item.details}` : ""}</span></div></div>)}{!data.auditLogs.length && <p className="muted-message">As próximas alterações feitas no sistema aparecerão aqui.</p>}</div></article>
            </section>
          )}
        </div>
      </main>

      {modal === "gestor" && <Modal title="Cadastrar acesso" text="Escolha se a pessoa será gestora de equipe ou administradora do sistema." onClose={() => setModal(null)}><form onSubmit={(event) => void submitManager(event)}><label>Nome completo<input name="name" required placeholder="Nome da pessoa" /></label><label>E-mail de acesso<input name="email" type="email" required placeholder="nome@empresa.com.br" /></label><div className="form-grid two"><label>Área ou unidade<input name="area" required placeholder="Ex.: Operações — Campinas" /></label><label>Nível de acesso<select name="role" required defaultValue="gestor"><option value="gestor">Gestor — somente sua equipe</option><option value="admin">Administrador — acesso completo</option></select></label></div><div className="admin-access-warning"><strong>Administrador</strong><span>Consegue visualizar e alterar dados de todas as equipes. Conceda esse acesso somente a pessoas autorizadas.</span></div><div className="form-actions"><button type="button" className="button secondary" onClick={() => setModal(null)}>Cancelar</button><button className="button primary" disabled={busy}>{busy ? "Salvando…" : "Liberar acesso"}</button></div></form></Modal>}
      {modal === "editar-gestor" && selectedManager && <Modal title="Editar gestor ou administrador" text="Atualize os dados, o nível de acesso ou defina um novo código numérico." onClose={() => { setModal(null); setSelectedManagerEmail(""); }}><form onSubmit={(event) => void updateManager(event)}><label>Nome completo<input name="name" required defaultValue={selectedManager.name} /></label><label>E-mail<input value={selectedManager.email} disabled /></label><div className="form-grid two"><label>Área ou unidade<input name="area" required defaultValue={selectedManager.area} /></label><label>Nível de acesso<select name="role" required defaultValue={selectedManager.role}><option value="gestor">Gestor — somente sua equipe</option><option value="admin">Administrador — acesso completo</option></select></label></div><label>Novo código de acesso — opcional<input name="newPin" type="password" inputMode="numeric" pattern="[0-9]{4,6}" minLength={4} maxLength={6} placeholder="Deixe vazio para manter o atual" /></label><div className="form-actions"><button type="button" className="button secondary" onClick={() => { setModal(null); setSelectedManagerEmail(""); }}>Cancelar</button><button className="button primary" disabled={busy}>{busy ? "Salvando…" : "Salvar alterações"}</button></div></form></Modal>}
      {modal === "colaborador" && <Modal title="Novo colaborador" text="Inclua os dados básicos para iniciar o acompanhamento." onClose={() => setModal(null)}><form onSubmit={(event) => void submitEmployee(event)}><label>Nome completo<input name="name" required /></label><div className="form-grid two"><label>Cargo<input name="jobRole" required /></label><label>Área<input name="area" required /></label></div><div className="form-grid two"><label>Data de nascimento<input name="birthDate" type="date" required max={new Date().toISOString().slice(0, 10)} /></label><label>Data de admissão<input name="admissionDate" type="date" required max={new Date().toISOString().slice(0, 10)} /></label></div>{isAdmin && <label>Gestor responsável<select name="managerEmail" required><option value="">Selecione…</option><option value={data.profile.email}>{data.profile.name} — Administrador</option>{managers.map((manager) => <option value={manager.email} key={manager.email}>{manager.name} — {manager.area}</option>)}</select></label>}<div className="form-actions"><button type="button" className="button secondary" onClick={() => setModal(null)}>Cancelar</button><button className="button primary" disabled={busy}>{busy ? "Salvando…" : "Adicionar"}</button></div></form></Modal>}
      {modal === "editar-colaborador" && selectedEmployee && <Modal title="Editar funcionário" text="Atualize os dados cadastrais e, se necessário, o gestor responsável." onClose={() => setModal(null)}><form onSubmit={(event) => void updateEmployee(event)}><label>Nome completo<input name="name" required defaultValue={selectedEmployee.name} /></label><div className="form-grid two"><label>Cargo<input name="jobRole" required defaultValue={selectedEmployee.jobRole} /></label><label>Área<input name="area" required defaultValue={selectedEmployee.area} /></label></div><div className="form-grid two"><label>Data de nascimento<input name="birthDate" type="date" required defaultValue={selectedEmployee.birthDate} max={new Date().toISOString().slice(0, 10)} /></label><label>Data de admissão<input name="admissionDate" type="date" required defaultValue={selectedEmployee.admissionDate} max={new Date().toISOString().slice(0, 10)} /></label></div>{isAdmin && <label>Gestor responsável<select name="managerEmail" required defaultValue={selectedEmployee.managerEmail}>{activeProfiles.map((manager) => <option value={manager.email} key={manager.email}>{manager.name} — {manager.role === "admin" ? "Administrador" : manager.area}</option>)}</select></label>}<div className="form-actions"><button type="button" className="button secondary" onClick={() => setModal(null)}>Cancelar</button><button className="button primary" disabled={busy}>{busy ? "Salvando…" : "Salvar alterações"}</button></div></form></Modal>}
      {modal === "importar-colaboradores" && <Modal wide title="Importar colaboradores" text={isAdmin ? "A planilha deve informar o e-mail de um gestor ativo em cada linha." : "Todos os colaboradores importados serão vinculados automaticamente à sua equipe."} onClose={closeImportModal}><div className="import-guide"><span>1</span><p><strong>Use o modelo</strong> com as colunas Nome completo, Cargo, Área e E-mail do gestor.</p><span>2</span><p><strong>Escolha o arquivo</strong> e confira erros ou duplicidades antes de salvar.</p></div><div className="import-file-actions"><button className="button secondary" onClick={downloadEmployeeImportTemplate}>⇩ Baixar modelo CSV</button><label className={`button primary import-file-button ${importLoading ? "disabled" : ""}`}>{importLoading ? "Lendo planilha…" : importFileName ? "Trocar arquivo" : "Escolher Excel ou CSV"}<input type="file" accept=".xlsx,.csv" onChange={(event) => void readEmployeeImportFile(event)} disabled={importLoading || busy} /></label></div>{importFileName && <p className="import-file-name">Arquivo: <strong>{importFileName}</strong></p>}{importRows.length > 0 && <><div className="import-summary"><div className="valid"><strong>{validImportRows.length}</strong><span>Prontos</span></div><div className="duplicate"><strong>{duplicateImportRows.length}</strong><span>Duplicados</span></div><div className="invalid"><strong>{errorImportRows.length}</strong><span>Com erro</span></div></div><div className="import-preview"><table><thead><tr><th>Linha</th><th>Colaborador</th><th>Cargo / Área</th><th>Gestor</th><th>Validação</th></tr></thead><tbody>{importRows.slice(0, 100).map((row) => <tr key={`${row.rowNumber}-${row.name}`}><td>{row.rowNumber}</td><td><strong>{row.name || "—"}</strong></td><td>{row.jobRole || "—"}<small>{row.area || "—"}</small></td><td>{row.managerName || "—"}<small>{row.managerEmail || "—"}</small></td><td><span className={`import-status ${row.status}`}>{row.issue}</span></td></tr>)}</tbody></table></div>{importRows.length > 100 && <p className="import-limit-note">Prévia das primeiras 100 linhas. Todas as {importRows.length} linhas validadas serão consideradas.</p>}</>}<div className="form-actions import-footer"><button type="button" className="button secondary" onClick={closeImportModal}>Cancelar</button><button type="button" className="button primary" disabled={!validImportRows.length || busy || importLoading} onClick={() => void importEmployees()}>{busy ? "Importando…" : `Importar ${validImportRows.length} colaborador${validImportRows.length === 1 ? "" : "es"}`}</button></div></Modal>}

      <div className={`toast ${toast ? "show" : ""}`}>{toast}</div>
    </div>
  );
}

function MetricCard({ label, value, detail }: { label: string; value: string; detail: string }) {
  return <article className="metric-card"><span>{label}</span><strong>{value}</strong><small>{detail}</small></article>;
}

function ManagerAccess({ busy, error, onSubmit }: { busy: boolean; error: string; onSubmit: (event: FormEvent<HTMLFormElement>, action: AccessAction) => Promise<boolean> }) {
  const [mode, setMode] = useState<"register" | "login" | "reset">("register");
  const [resetRequested, setResetRequested] = useState(false);
  const [resetEmail, setResetEmail] = useState("");

  async function submit(event: FormEvent<HTMLFormElement>) {
    const action: AccessAction = mode === "reset"
      ? resetRequested ? "resetPassword" : "requestReset"
      : mode;
    const success = await onSubmit(event, action);
    if (!success) return;
    if (action === "requestReset") setResetRequested(true);
    if (action === "resetPassword") {
      setMode("login");
      setResetRequested(false);
    }
  }

  return (
    <main className="login-page">
      <section className="login-brand">
        <div className="login-brand-content">
          <div className="brand-lockup login-lockup"><div className="brand-mark"><img src="/petcamp-logo.png" alt="Logo Petcamp" /></div><div><strong>Petcamp</strong><span>People Development</span></div></div>
          <span className="login-eyebrow">PDI CORPORATIVO</span>
          <h1>Desenvolva pessoas.<br />Fortaleça resultados.</h1>
          <p>Avaliações, PDIs e check-ins compartilhados entre gestores em uma experiência simples e profissional.</p>
          <div className="login-features"><span>✓ Cadastro de cada gestor</span><span>✓ Equipes separadas</span><span>✓ Dados centralizados</span></div>
        </div>
      </section>
      <section className="login-panel">
        <div className="login-card access-card">
          <div className="login-icon"><img src="/petcamp-logo.png" alt="Logo Petcamp" /></div>
          <span className="eyebrow dark">ACESSO DE GESTORES</span>
          <h2>{mode === "register" ? "Cadastre seu acesso" : mode === "login" ? "Entre no PDI Petcamp" : "Redefinir código de acesso"}</h2>
          <p>{mode === "register" ? "Cada gestor deve preencher seus dados e criar um código numérico." : mode === "login" ? "Informe o e-mail e o código que você criou no cadastro." : resetRequested ? "Digite o código recebido por e-mail e crie um novo acesso." : "Enviaremos um código de segurança para o e-mail cadastrado."}</p>
          {mode !== "reset" && <div className="access-tabs"><button className={mode === "register" ? "active" : ""} onClick={() => { setMode("register"); }}>Novo cadastro</button><button className={mode === "login" ? "active" : ""} onClick={() => { setMode("login"); }}>Já sou cadastrado</button></div>}
          {mode === "reset" && <button className="back-to-login" onClick={() => { setMode("login"); setResetRequested(false); }}>← Voltar para o acesso</button>}
          <form className="access-form" onSubmit={(event) => void submit(event)}>
            {mode === "register" && <><label>Nome completo<input name="name" required placeholder="Nome do gestor" autoComplete="name" /></label><label>Área ou unidade<input name="area" required placeholder="Ex.: Operações — Campinas" /></label></>}
            <label>E-mail<input name="email" type="email" required placeholder="gestor@empresa.com.br" autoComplete="email" value={mode === "reset" ? resetEmail : undefined} onChange={mode === "reset" ? (event) => setResetEmail(event.target.value) : undefined} /></label>
            {mode !== "reset" && <label>Código de acesso<input name="pin" type="password" inputMode="numeric" pattern="[0-9]{4,6}" minLength={4} maxLength={6} required placeholder="Crie de 4 a 6 números" autoComplete={mode === "login" ? "current-password" : "new-password"} /></label>}
            {mode === "reset" && resetRequested && <><label>Código recebido por e-mail<input name="resetCode" type="text" inputMode="numeric" pattern="[0-9]{6}" minLength={6} maxLength={6} required placeholder="000000" autoComplete="one-time-code" /></label><label>Novo código de acesso<input name="newPin" type="password" inputMode="numeric" pattern="[0-9]{4,6}" minLength={4} maxLength={6} required placeholder="Crie de 4 a 6 números" autoComplete="new-password" /></label></>}
            {error && <div className="access-error">{error}</div>}
            <button className="button primary login-button" disabled={busy}>{busy ? "Aguarde…" : mode === "register" ? "Cadastrar e entrar" : mode === "login" ? "Entrar" : resetRequested ? "Salvar novo código" : "Enviar código por e-mail"}</button>
          </form>
          {mode === "login" && <button className="forgot-link" onClick={() => setMode("reset")}>Esqueci meu código de acesso</button>}
          <small>Não é necessário possuir conta no ChatGPT. O primeiro cadastro será o administrador do sistema.</small>
        </div>
      </section>
    </main>
  );
}

function SectionHeader({ title, text, actionLabel, onAction }: { title: string; text: string; actionLabel?: string; onAction?: () => void }) {
  return <div className="section-header"><div><h2>{title}</h2><p>{text}</p></div>{actionLabel && onAction && <button className="button primary" onClick={onAction}>{actionLabel}</button>}</div>;
}

function EmptyState({ title, text, actionLabel, onAction, compact = false }: { title: string; text: string; actionLabel?: string; onAction: () => void; compact?: boolean }) {
  return <div className={`empty-state ${compact ? "compact" : ""}`}><div className="empty-icon">＋</div><h3>{title}</h3><p>{text}</p>{actionLabel && <button className="button primary" onClick={onAction}>{actionLabel}</button>}</div>;
}

function EmployeeCard({ employee, showManager, selected, onSelect }: { employee: Employee; showManager: boolean; selected: boolean; onSelect: (employeeId: number) => void }) {
  const statusClass = employee.archivedAt ? "muted" : employee.readiness === "Reversão" ? "danger" : employee.readiness === "Pronto" ? "success" : "blue";
  const age = yearsSince(employee.birthDate);
  return <article className={`employee-card ${selected ? "employee-selected" : ""} ${employee.readiness === "Reversão" && !employee.archivedAt ? "employee-reversal" : ""} ${employee.archivedAt ? "employee-archived" : ""}`}><label className="employee-select"><input type="checkbox" checked={selected} onChange={() => onSelect(employee.id)} /><span>Selecionar</span></label><div className="employee-heading"><div className="avatar large">{initials(employee.name)}</div><div><h3>{employee.name}</h3><p>{employee.jobRole}</p></div></div><div className="employee-details"><div><span>Área</span><strong>{employee.area}</strong></div><div><span>Idade</span><strong>{age === null ? "Não informada" : `${age} anos`}</strong></div><div><span>Admissão</span><strong>{employee.admissionDate ? formatDate(employee.admissionDate) : "Não informada"}</strong></div><div><span>Tempo de empresa</span><strong>{companyTime(employee.admissionDate)}</strong></div><div><span>Nota</span><strong>{employee.score ? employee.score.toFixed(1).replace(".", ",") : "—"}</strong></div><div><span>PDI</span><strong className={`badge ${employee.pdiStatus === "PDI pendente" ? "warning" : "blue"}`}>{employee.pdiStatus}</strong></div><div><span>Status</span><strong className={`badge ${statusClass}`}>{employee.archivedAt ? "Arquivado" : employee.readiness}</strong></div></div>{showManager && <div className="manager-line"><span>Gestor responsável</span><strong>{employee.managerName}</strong></div>}</article>;
}

function TeamTable({ employees }: { employees: Employee[] }) {
  return <article className="card team-card"><div className="card-heading"><div><h3>Visão da equipe</h3><p>Status individual de desenvolvimento</p></div></div><div className="table-wrap"><table><thead><tr><th>Colaborador</th><th>Cargo</th><th>Gestor</th><th>Nota</th><th>PDI</th><th>Status</th></tr></thead><tbody>{employees.map((employee) => <tr key={employee.id}><td><strong>{employee.name}</strong></td><td>{employee.jobRole}</td><td>{employee.managerName}</td><td><strong>{employee.score ? employee.score.toFixed(1).replace(".", ",") : "—"}</strong></td><td><span className={`badge ${employee.pdiStatus === "PDI pendente" ? "warning" : "blue"}`}>{employee.pdiStatus}</span></td><td><span className={`badge ${employee.readiness === "Reversão" ? "danger" : employee.readiness === "Pronto" ? "success" : "blue"}`}>{employee.readiness}</span></td></tr>)}</tbody></table></div></article>;
}

function ActionBox({ weight, title, description, name, required = false }: { weight: string; title: string; description: string; name: string; required?: boolean }) {
  return <label className="action-box"><span className="weight">{weight}</span><strong>{title}</strong><small>{description}</small><textarea name={name} rows={6} required={required} placeholder="Descreva a ação de desenvolvimento…" /></label>;
}

function Modal({ title, text, onClose, children, wide = false }: { title: string; text: string; onClose: () => void; children: React.ReactNode; wide?: boolean }) {
  return <div className="modal-backdrop" role="presentation" onMouseDown={(event) => event.target === event.currentTarget && onClose()}><div className={`modal ${wide ? "modal-wide" : ""}`} role="dialog" aria-modal="true" aria-label={title}><div className="modal-heading"><div><h2>{title}</h2><p>{text}</p></div><button onClick={onClose} aria-label="Fechar">×</button></div>{children}</div></div>;
}
