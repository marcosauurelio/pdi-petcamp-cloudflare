drop policy if exists "Gestores podem excluir suas avaliacoes"
on public.evaluations;

create policy "Gestores podem excluir suas avaliacoes"
on public.evaluations
for delete
to authenticated
using (
  lower(manager_email) = lower(coalesce(auth.jwt() ->> 'email', ''))
  and public.current_user_is_active()
);

drop policy if exists "Administradores podem excluir avaliacoes"
on public.evaluations;

create policy "Administradores podem excluir avaliacoes"
on public.evaluations
for delete
to authenticated
using (public.current_user_is_admin());
