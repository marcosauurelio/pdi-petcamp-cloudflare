alter table public.employees
  add column if not exists birth_date date,
  add column if not exists admission_date date;

comment on column public.employees.birth_date is 'Data de nascimento do colaborador';
comment on column public.employees.admission_date is 'Data de admissão do colaborador';
