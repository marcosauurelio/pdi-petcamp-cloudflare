import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "PDI Petcamp Multi Gestores",
  description: "Sistema corporativo de avaliação de desempenho, PDI e acompanhamento de equipes da Petcamp.",
  other: {
    "codex-preview": "development",
  },
  icons: {
    icon: "/petcamp-logo.png",
    shortcut: "/petcamp-logo.png",
    apple: "/petcamp-logo.png",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="pt-BR">
      <body className="antialiased">{children}</body>
    </html>
  );
}
