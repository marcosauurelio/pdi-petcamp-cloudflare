import { cleanEmail, cleanText, pinPassword, sessionCookie, supabaseAuth } from "@/lib/supabase-server";

function json(payload: Record<string, unknown>, status = 200, cookie?: string) {
  const headers = new Headers({ "content-type": "application/json" });
  if (cookie) headers.set("set-cookie", cookie);
  return new Response(JSON.stringify(payload), { status, headers });
}

async function authPayload(response: Response) {
  const data = await response.json().catch(() => ({})) as Record<string, unknown>;
  if (!response.ok) {
    const raw = String(data.msg || data.message || data.error_description || "Não foi possível acessar.");
    const message = raw.includes("Invalid login") ? "E-mail ou código de acesso incorreto."
      : raw.includes("already registered") ? "Este gestor já está cadastrado. Use a opção Entrar."
      : raw.includes("Email not confirmed") ? "Confirme o cadastro no e-mail recebido antes de entrar."
      : raw;
    throw new Error(message);
  }
  return data;
}

export async function POST(request: Request) {
  try {
    const payload = (await request.json()) as Record<string, unknown>;
    const action = cleanText(payload.action, 20);
    if (action === "logout") return json({ ok: true }, 200, sessionCookie("", 0));

    const email = cleanEmail(payload.email);
    if (action === "requestReset") {
      if (!email) return json({ error: "Informe um e-mail válido." }, 400);
      await supabaseAuth("recover", { email });
      return json({ ok: true, message: "Se o e-mail estiver cadastrado, o Supabase enviará a recuperação." });
    }
    if (action === "resetPassword") return json({ error: "Use o link de recuperação enviado ao seu e-mail." }, 400);

    const pin = cleanText(payload.pin, 8);
    if (!email || !/^\d{4,6}$/.test(pin)) return json({ error: "Informe um e-mail válido e um código de 4 a 6 números." }, 400);

    if (action === "register") {
      const name = cleanText(payload.name, 100);
      const area = cleanText(payload.area, 100);
      if (!name || !area) return json({ error: "Preencha nome, e-mail, área e código de acesso." }, 400);
      const response = await supabaseAuth("signup", { email, password: pinPassword(pin), data: { name, area } });
      const data = await authPayload(response);
      const accessToken = String(data.access_token || "");
      return json(
        { ok: true, message: accessToken ? "Cadastro concluído e acesso liberado." : "Cadastro criado. Confirme o e-mail para entrar." },
        201,
        accessToken ? sessionCookie(accessToken, Number(data.expires_in || 3600)) : undefined,
      );
    }

    if (action === "login") {
      const response = await supabaseAuth("token?grant_type=password", { email, password: pinPassword(pin) });
      const data = await authPayload(response);
      return json({ ok: true, message: "Acesso liberado." }, 200, sessionCookie(String(data.access_token), Number(data.expires_in || 3600)));
    }

    return json({ error: "Ação não reconhecida." }, 400);
  } catch (error) {
    return json({ error: error instanceof Error ? error.message : "Não foi possível acessar o sistema." }, 500);
  }
}
