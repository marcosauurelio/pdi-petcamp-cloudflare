import { getProfile, rest } from "@/lib/supabase-server";

type Row = Record<string, unknown>;

export async function GET(request: Request) {
  try {
    const profile = await getProfile(request);
    if (!profile || !profile.active) return Response.json({ error: "Cadastre-se ou entre para acessar o PDI.", registrationRequired: true }, { status: 401 });

    const [profiles, employeeRows, evaluationRows, pdiRows, checkinRows, auditRows] = await Promise.all([
      rest<Row[]>(request, "profiles?select=email,name,role,area,active&order=active.desc,role.asc,name.asc"),
      rest<Row[]>(request, "employees?select=*&order=archived_at.asc.nullsfirst,name.asc"),
      rest<Row[]>(request, "evaluations?select=*&order=created_at.desc&limit=200"),
      rest<Row[]>(request, "pdis?select=*&order=created_at.desc&limit=200"),
      rest<Row[]>(request, "checkins?select=*&order=checkin_date.desc,created_at.desc&limit=200"),
      rest<Row[]>(request, "audit_logs?select=*&order=created_at.desc,id.desc&limit=300"),
    ]);
    const names = new Map(profiles.map((item) => [String(item.email), String(item.name)]));
    const employees = employeeRows.map((item) => ({
      id: Number(item.id), name: item.name, jobRole: item.job_role, area: item.area,
      birthDate: item.birth_date || "", admissionDate: item.admission_date || "",
      managerEmail: item.manager_email, managerName: names.get(String(item.manager_email)) || item.manager_email,
      score: Number(item.score), pdiStatus: item.pdi_status, readiness: item.readiness, archivedAt: item.archived_at,
    }));
    const employeeNames = new Map(employees.map((item) => [item.id, String(item.name)]));
    return Response.json({
      profile: { ...profile, active: profile.active ? 1 : 0 },
      managers: profiles.map((item) => ({ ...item, active: item.active ? 1 : 0 })),
      employees,
      evaluations: evaluationRows.map((item) => ({
        id: Number(item.id), employeeId: Number(item.employee_id), employeeName: employeeNames.get(Number(item.employee_id)) || "",
        managerEmail: item.manager_email, managerName: names.get(String(item.manager_email)) || item.manager_email,
        cycle: item.cycle, overall: Number(item.overall), answers: item.answers || [], competencyAverages: item.competency_averages || {},
        comments: item.comments, status: item.status, createdAt: item.created_at,
      })),
      pdis: pdiRows.map((item) => ({
        id: Number(item.id), employeeId: Number(item.employee_id), employeeName: employeeNames.get(Number(item.employee_id)) || "",
        managerEmail: item.manager_email, competency: item.competency, action70: item.action_70, action20: item.action_20,
        action10: item.action_10, deadline: item.deadline, successIndicator: item.success_indicator, status: item.status, createdAt: item.created_at,
      })),
      checkins: checkinRows.map((item) => ({
        id: Number(item.id), employeeId: Number(item.employee_id), employeeName: employeeNames.get(Number(item.employee_id)) || "",
        managerEmail: item.manager_email, date: item.checkin_date, progress: item.progress, risks: item.risks,
        nextActions: item.next_actions, createdAt: item.created_at,
      })),
      auditLogs: auditRows.map((item) => ({
        id: Number(item.id), actorEmail: item.actor_email, actorName: item.actor_name, action: item.action,
        targetType: item.target_type, targetName: item.target_name, details: item.details, createdAt: item.created_at,
      })),
    });
  } catch (error) {
    const message = error instanceof Error ? error.message : "Não foi possível carregar os dados.";
    return Response.json({ error: message === "UNAUTHORIZED" ? "Sessão encerrada. Entre novamente." : message }, { status: message === "UNAUTHORIZED" ? 401 : 500 });
  }
}
