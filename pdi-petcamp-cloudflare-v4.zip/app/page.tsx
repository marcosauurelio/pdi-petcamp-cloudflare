import PdiClient from "./pdi-client";

export default function Home() {
  return <PdiClient />;
}
